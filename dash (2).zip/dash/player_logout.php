<?php
session_start();
session_destroy();
header("Location: player_login.php");
exit();