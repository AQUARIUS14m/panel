<?php
$host = 'localhost';
$user = 'nC';
$pass = '15'; // رمز دیتابیس
$dbname = 'nC';

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("خطا در اتصال به دیتابیس: " . $conn->connect_error);
}
?>