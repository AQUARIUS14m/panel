<?php
session_start();
require_once "db.php";
header('Content-Type: text/html; charset=utf-8');
$username = $_SESSION['player_username'] ?? "Mahdi";

// اتصال به دیتابیس با PDO
$pdo = new PDO('mysql:host=localhost;dbname=nC;charset=utf8mb4', 'nC', '15', [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
]);

// گرفتن موجودی NovaCoin
$stmt = $pdo->prepare("SELECT coins FROM novacoin WHERE username=?");
$stmt->execute([$username]);
$novacoin = intval($stmt->fetchColumn() ?? 0);

// لیست آیتم‌های عظیم و متنوع
$items = [
    ['id'=>1,'type'=>'rank','title'=>'رنک VIP','desc'=>'دسترسی ویژه و امکانات خاص','img'=>'/assets/vip.png','price'=>100,'currency'=>'novacoin','code'=>'VIP'],
    ['id'=>2,'type'=>'rank','title'=>'رنک LEGEND','desc'=>'VIP + آیتم خاص و قابلیت ویژه','img'=>'/assets/legend.png','price'=>200,'currency'=>'novacoin','code'=>'LEGEND'],
    ['id'=>3,'type'=>'rank','title'=>'رنک GOD','desc'=>'قوی‌ترین رنک سرور با امکانات بی‌نهایت','img'=>'/assets/god.png','price'=>400,'currency'=>'novacoin','code'=>'GOD'],
    ['id'=>4,'type'=>'rank','title'=>'رنک ULTRA','desc'=>'رنک با قابلیت پرواز و نامرئی شدن','img'=>'/assets/ultra.png','price'=>320,'currency'=>'novacoin','code'=>'ULTRA'],
    ['id'=>5,'type'=>'rank','title'=>'رنک MVP','desc'=>'رنک برای پلیرهای وفادار و فعال','img'=>'/assets/mvp.png','price'=>180,'currency'=>'novacoin','code'=>'MVP'],
    ['id'=>6,'type'=>'rank','title'=>'رنک Royal','desc'=>'شمشیر با قدرت ویژه و افکت','img'=>'/assets/sword.png','price'=>70,'currency'=>'novacoin','code'=>'ROYAL'],
    ['id'=>7,'type'=>'rank','title'=>'رنک TITAN','desc'=>'ست کامل زره الماس','img'=>'/assets/armor.png','price'=>120,'currency'=>'novacoin','code'=>'TITAN'],
    ['id'=>8,'type'=>'rank','title'=>'رنک VIP+','desc'=>'امکان پرواز آزاد در سرور','img'=>'/assets/fly.png','price'=>110,'currency'=>'novacoin','code'=>'VIP+'],
    ['id'=>9,'type'=>'rank','title'=>'رنک MVP+','desc'=>'داشتن یک نقطه تلپورت خصوصی','img'=>'/assets/warp.png','price'=>60,'currency'=>'novacoin','code'=>'MVP+'],
    ['id'=>10,'type'=>'rank','title'=>'رنک LEGEND+','desc'=>'خانه با پارکینگ و استخر','img'=>'/assets/home.png','price'=>300,'currency'=>'novacoin','code'=>'LEGEND+'],
];
// هندل خرید ایجکس
if(isset($_POST['buy_item_id'])){
    $item_id = intval($_POST['buy_item_id']);
    $item = null;
    foreach($items as $it) if($it['id']==$item_id) $item = $it;
    if(!$item) exit(json_encode(['error'=>'آیتم وجود ندارد.']));

    // موجودی جدید (دوباره از دیتابیس بگیر)
    $stmt = $pdo->prepare("SELECT coins FROM novacoin WHERE username=?");
    $stmt->execute([$username]);
    $novacoin = intval($stmt->fetchColumn() ?? 0);

    if($novacoin < $item['price']) exit(json_encode(['error'=>'موجودی کافی نیست.']));

    try{
        $pdo->beginTransaction();
        // کم کردن کوین فقط اگر کافی باشد
        $res = $pdo->prepare("UPDATE novacoin SET coins = coins - ? WHERE username=? AND coins >= ?");
        $res->execute([$item['price'], $username, $item['price']]);
        if($res->rowCount() == 0) throw new Exception('موجودی کافی نیست.');

        // اعمال رنک در دیتابیس
        if($item['type']=='rank'){
            $res = $pdo->prepare("SELECT Name FROM ranksystemusers WHERE Name=?");
            $res->execute([$username]);
            if($res->fetchColumn()){
                $pdo->prepare("UPDATE ranksystemusers SET Ranks=? WHERE Name=?")
                    ->execute([$item['code'],$username]);
            }else{
                $pdo->prepare("INSERT INTO ranksystemusers (name,ranks,permissions) VALUES (?,?,?)")
                    ->execute([$username,$item['code'],'player']);
            }
        }
        $pdo->commit();
    }catch(Exception $e){
        $pdo->rollBack();
        exit(json_encode(['error'=>$e->getMessage()]));
    }

    // ثبت خرید در pending_ranks.txt برای پلاگین ShopAPI
    $filePath = "d:/aula/lobby/plugin_data/ShopAPI/pending_ranks.txt";
    if($item['type'] === 'rank'){
        file_put_contents($filePath, "$username:{$item['code']}\n", FILE_APPEND);
    }

    // موجودی جدید
    $stmt = $pdo->prepare("SELECT coins FROM novacoin WHERE username=?");
    $stmt->execute([$username]);
    $new_balance = intval($stmt->fetchColumn() ?? 0);

    exit(json_encode([
        'success'=>1,
        'msg'=>"✅ خرید با موفقیت انجام شد!",
        'new_balance'=>$new_balance
    ]));
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>فروشگاه NovaCoin | شاپ آنلاین</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700&display=swap">
    <style>
        :root{
            --main:#c0c0c0; /* نقره ای */
            --silver-light:#e5e5e5;
            --silver-mid:#b5b5b5;
            --silver-dark:#757575;
            --dark:#1a1a1a;
            --light:#fafafc;
            --gray:#23282f;
        }
        html,body{
            background:linear-gradient(135deg, var(--silver-light) 0%, var(--silver-mid) 100%);
            margin:0;padding:0;
            color:var(--dark);
            font-family:'Vazirmatn',Tahoma,Arial,sans-serif;
            min-height:100vh;
        }
        [data-theme="dark"] html,[data-theme="dark"] body{
            background:linear-gradient(120deg, #222 0%, #606060 100%);
            color:#f4f4f4;
        }
        .shop-container{
            max-width:1280px;
            margin:40px auto 0 auto;
            border-radius:38px;
            background:rgba(255,255,255,0.07);
            box-shadow:0 24px 72px #b5b5b588,0 0 0 4px var(--main);
            padding:44px 32px;
            position:relative;
        }
        [data-theme="dark"] .shop-container{
            background:rgba(34,34,34,0.98);
            box-shadow:0 24px 72px #23282f44,0 0 0 4px var(--silver-dark);
        }
        .shop-header{
            display:flex;align-items:center;justify-content:space-between;margin-bottom:32px;
        }
        .shop-title{
            font-size:2.4rem;
            font-weight:900;
            color:var(--main);
            letter-spacing:-1px;
            text-shadow:0 1px 14px #b5b5b5b0, 0 1px 0 #fff;
        }
        .shop-user{font-size:1.25rem;color:var(--silver-dark);margin-bottom:9px;}
        .shop-balance{
            font-size:1.18rem;
            color:#fff;
            background:linear-gradient(90deg,var(--main) 0%,var(--silver-mid) 100%);
            border-radius:18px;
            display:inline-block;
            padding:10px 30px;
            margin-bottom:29px;
            box-shadow:0 2px 18px #b5b5b566;
        }
        [data-theme="dark"] .shop-balance{
            color:var(--main);
            background:linear-gradient(90deg,var(--silver-dark) 0%,#333 100%);
        }
        .theme-btn{
            background:var(--silver-mid);
            border:none;
            border-radius:16px;
            color:#333;
            font-size:1.18rem;
            padding:10px 30px;
            cursor:pointer;
            box-shadow:0 1px 12px #b5b5b566;
            transition:background .13s, color .13s;
        }
        .theme-btn:hover{background:var(--main);color:#111;}
        .back-btn{
            background:var(--main);
            color:#23282f;
            border-radius:15px;
            border:none;
            font-size:1.11rem;
            padding:11px 22px;
            cursor:pointer;
            margin-left:12px;
            box-shadow:0 1px 8px #b5b5b566;
        }
        .shop-cards{
            display:flex;flex-wrap:wrap;gap:40px 28px;justify-content:center;margin-top:24px;
        }
        .shop-card{
            background:linear-gradient(135deg, #fff 0%, var(--silver-light) 100%);
            border-radius:29px;
            border:3px solid var(--main);
            box-shadow:0 10px 48px 0 #b5b5b5aa,0 0 0 2px #e5e5e5;
            display:flex;flex-direction:column;align-items:center;
            min-width:260px;max-width:360px;width:300px;min-height:350px;position:relative;
            transition:.22s cubic-bezier(.49,1.44,.57,1.22);
            overflow:hidden;
        }
        [data-theme="dark"] .shop-card{
            background:linear-gradient(120deg,#23282f 0%, #757575 100%);
            border:3px solid #757575;
            box-shadow:0 10px 40px 0 #000a,0 0 0 2px #757575;
        }
        .shop-card:hover{
            border-color:var(--silver-dark);
            box-shadow:0 18px 66px 0 #b5b5b5ee;
            transform:translateY(-7px) scale(1.025);
        }
        .shop-card-img{
            width:120px;height:120px;margin-top:30px;margin-bottom:15px;
            border-radius:22px;
            box-shadow:0 8px 36px 0 #c0c0c045;
            background:linear-gradient(100deg,#c0c0c0 0%,#fff 100%);
            object-fit:cover;
        }
        .shop-card-title{
            font-size:1.23rem;
            font-weight:700;
            color:var(--silver-dark);
            margin-bottom:10px;
            text-align:center;
        }
        [data-theme="dark"] .shop-card-title{color:var(--main);}
        .shop-card-desc{
            font-size:1.08rem;
            color:#5a5a5a;
            text-align:center;
            margin-bottom:14px;
            min-height:48px;
        }
        [data-theme="dark"] .shop-card-desc{color:#e5e5e5;}
        .shop-card-price{
            font-size:1.15rem;
            color:var(--silver-dark);
            font-weight:700;
            margin-bottom:20px;
            text-align:center;
        }
        .shop-card-btn{
            width:85%;padding:15px 0 13px 0;
            background:linear-gradient(90deg,var(--main) 0%,var(--silver-mid) 100%);
            color:#23282f;
            font-weight:700;
            font-size:1.13rem;
            border-radius:16px;
            border:none;
            cursor:pointer;
            margin-bottom:24px;margin-top:auto;
            box-shadow:0 1px 12px 0 #b5b5b5aa;
            transition:.13s;
        }
        .shop-card-btn:disabled{
            background:#d1d1d1;color:#888;cursor:not-allowed;opacity:.7;
            box-shadow:none;
        }
        .shop-card-btn:hover:not(:disabled){
            filter:brightness(1.09);
            background:linear-gradient(90deg,var(--silver-mid) 0%,var(--main) 100%);
        }
        .shop-badge{
            position:absolute;left:20px;top:18px;
            background:linear-gradient(90deg,var(--silver-mid) 0%,var(--main) 100%);
            color:#23282f;
            border-radius:12px;
            font-size:1.02rem;
            padding:5px 17px 5px 13px;
            box-shadow:0 1px 12px #b5b5b522;
            font-weight:bold;
            z-index:2;
        }
        .alert-success{
            background:linear-gradient(90deg,#e5f4e5 0%,#b5e5b5 100%);
            color:#158d15;
            border-radius:13px;
            padding:13px 19px;
            margin:30px 0 22px 0;
            font-size:1.12rem;
        }
        .alert-error{
            background:linear-gradient(90deg,#faeaea 0%,#f5cccc 100%);
            color:#d34343;
            border-radius:13px;
            padding:13px 19px;
            margin:30px 0 22px 0;
            font-size:1.12rem;
        }
        @media (max-width:900px){
            .shop-container{padding:13px;}
            .shop-title{font-size:1.6rem;}
            .shop-header{flex-direction:column;gap:16px;}
            .shop-cards{gap:20px;}
            .shop-card{width:99vw;min-width:180px;}
            .shop-balance{font-size:1.01rem;padding:8px 17px;}
        }
        ::-webkit-scrollbar{width:10px;background:rgba(200,200,200,0.14);border-radius:10px;}
        ::-webkit-scrollbar-thumb{background:#bababa;border-radius:10px;}
    </style>
</head>
<body>
<div class="shop-container">
    <div class="shop-header">
        <button class="back-btn" onclick="window.location='dashboard.php'">⟵ بازگشت</button>
        <span class="shop-title">فروشگاه عظیم NovaCoin</span>
        <button class="theme-btn" id="theme-btn" title="تغییر حالت روز/شب">🌙</button>
    </div>
    <div class="shop-user">سلام، <?=htmlspecialchars($username)?> 👋</div>
    <div class="shop-balance">موجودی: <b id="coin-balance"><?=number_format($novacoin)?></b> <span style="color:var(--main)">NovaCoin</span></div>
    <div id="shop-msg"></div>
    <div class="shop-cards" id="shop-cards">
        <?php foreach($items as $item): ?>
        <div class="shop-card">
            <div class="shop-badge"><?=($item['type']=='rank'?'رنک':($item['type']=='home'?'خانه':'آیتم'))?></div>
            <img class="shop-card-img" src="<?=htmlspecialchars($item['img'])?>" alt="<?=htmlspecialchars($item['title'])?>">
            <div class="shop-card-title"><?=htmlspecialchars($item['title'])?></div>
            <div class="shop-card-desc"><?=htmlspecialchars($item['desc'])?></div>
            <div class="shop-card-price">قیمت: <span style="color:var(--main)"><?=number_format($item['price'])?> NovaCoin</span></div>
            <button class="shop-card-btn" data-id="<?=$item['id']?>" <?=($novacoin<$item['price']?'disabled':'')?>>خرید</button>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<script>
// تم روشن/تاریک نقره‌ای
const themeBtn = document.getElementById('theme-btn');
const html = document.documentElement;
function setTheme(mode){
    if(mode==='dark'){
        html.setAttribute('data-theme','dark');
        themeBtn.innerHTML = "🌙";
    }else{
        html.setAttribute('data-theme','light');
        themeBtn.innerHTML = "🌞";
    }
    localStorage.setItem('shop_theme',mode);
}
themeBtn.onclick = function(){
    let mode = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    setTheme(mode);
};
(function(){
    let mode = localStorage.getItem('shop_theme');
    setTheme(mode==='dark'?'dark':'light');
})();

// خرید آیتم
document.querySelectorAll('.shop-card-btn').forEach(btn=>{
    btn.onclick = function(){
        let id = this.getAttribute('data-id');
        this.disabled = true;
        document.getElementById('shop-msg').innerHTML = '';
        fetch(location.href, {
            method:'POST',
            headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'buy_item_id='+encodeURIComponent(id)
        }).then(r=>r.json()).then(data=>{
            if(data.success){
                document.getElementById('shop-msg').innerHTML = `<div class="alert-success">${data.msg}</div>`;
                document.getElementById('coin-balance').textContent = (data.new_balance).toLocaleString();
                document.querySelectorAll('.shop-card-btn').forEach(x=>{
                    let price = parseInt(x.parentElement.querySelector('.shop-card-price').textContent.replace(/\D/g,''));
                    x.disabled = (data.new_balance<price);
                });
            }else{
                document.getElementById('shop-msg').innerHTML = `<div class="alert-error">${data.error||'خطا رخ داد!'}</div>`;
                this.disabled = false;
            }
        }).catch(()=>{
            document.getElementById('shop-msg').innerHTML = `<div class="alert-error">ارتباط با سرور برقرار نشد!</div>`;
            this.disabled = false;
        });
    }
});
</script>
</body>
</html>