<?php
session_start();
$allowed_roles = ['admin','manager','owner'];
$_SESSION['player_role'] = $_SESSION['player_role'] ?? 'admin';
if (!in_array($_SESSION['player_role'], $allowed_roles)) {
    die('<div style="color:red;padding:3em;font-size:1.2em;text-align:center;">دسترسی غیرمجاز</div>');
}
$host = 'localhost';
$user = 'nC';
$pass = '15';
$dbname = 'nC';
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) { die("DB Error."); }
header('Content-Type: text/html; charset=utf-8');
if (isset($_GET['api'])) {
    if ($_GET['api'] === 'tickets') {
        $arr = [];
        $search = trim($_GET['search'] ?? '');
        $where = $search ? "WHERE (id=? OR user LIKE CONCAT('%',?,'%') OR title LIKE CONCAT('%',?,'%'))" : '';
        $query = "SELECT id, user, title, status, DATE_FORMAT(created_at, '%Y/%m/%d %H:%i') as date, 
            (SELECT COUNT(*) FROM ticket_messages WHERE ticket_id=tickets.id) as msg_count 
            FROM tickets $where ORDER BY status='open' DESC, id DESC";
        if ($search) {
            $stmt = $conn->prepare($query);
            $stmt->bind_param("iss", $search, $search, $search);
        } else {
            $stmt = $conn->prepare($query);
        }
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) $arr[] = $row;
        $stmt->close();
        echo json_encode($arr, JSON_UNESCAPED_UNICODE); exit;
    }
    if ($_GET['api'] === 'messages' && isset($_GET['ticket_id'])) {
        $ticket_id = intval($_GET['ticket_id']);
        $arr = [];
        $stmt = $conn->prepare("SELECT sender, sender_type, message, DATE_FORMAT(sent_at, '%H:%i') as time FROM ticket_messages WHERE ticket_id=? ORDER BY id ASC");
        $stmt->bind_param("i", $ticket_id);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) $arr[] = $row;
        $stmt->close();
        echo json_encode($arr, JSON_UNESCAPED_UNICODE); exit;
    }
    if ($_GET['api'] === 'ticket_details' && isset($_GET['ticket_id'])) {
        $ticket_id = intval($_GET['ticket_id']);
        $stmt = $conn->prepare("SELECT *, (SELECT COUNT(*) FROM ticket_messages WHERE ticket_id=tickets.id) as msg_count FROM tickets WHERE id=?");
        $stmt->bind_param("i", $ticket_id);
        $stmt->execute();
        $t = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($t) {
            echo json_encode([
                'title' => $t['title'],
                'status' => $t['status'],
                'created_at' => $t['created_at'],
                'id' => $t['id'],
                'user' => $t['user'],
                'msg_count' => $t['msg_count']
            ], JSON_UNESCAPED_UNICODE); exit;
        }
        echo json_encode(['err'=>'not found']); exit;
    }
    if ($_GET['api']=='send_message' && $_SERVER['REQUEST_METHOD']==='POST') {
        $ticket_id = intval($_POST['ticket_id']??0);
        $msg = trim($_POST['message']??'');
        $staff = $_SESSION['player_username'] ?? 'Supporter';
        if (!$ticket_id || !$msg) { http_response_code(422); exit("اطلاعات ناقص."); }
        $stmt = $conn->prepare("SELECT status FROM tickets WHERE id=?");
        $stmt->bind_param("i", $ticket_id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$row) { http_response_code(404); exit("تیکت وجود ندارد."); }
        if ($row['status'] !== 'open') { http_response_code(403); exit("تیکت بسته است."); }
        $stmt = $conn->prepare("INSERT INTO ticket_messages (ticket_id, sender, sender_type, message) VALUES (?, ?, 'staff', ?)");
        $stmt->bind_param("iss", $ticket_id, $staff, $msg);
        $stmt->execute();
        $stmt->close();
        echo json_encode(['ok'=>1]); exit;
    }
    if ($_GET['api']=='close_ticket' && isset($_POST['ticket_id'])) {
        $ticket_id = intval($_POST['ticket_id']);
        $stmt = $conn->prepare("UPDATE tickets SET status='closed' WHERE id=?");
        $stmt->bind_param("i", $ticket_id);
        $stmt->execute();
        $stmt->close();
        echo json_encode(['ok'=>1]); exit;
    }
    // باز کردن تیکت بسته توسط ادمین
    if ($_GET['api']=='open_ticket' && isset($_POST['ticket_id'])) {
        $ticket_id = intval($_POST['ticket_id']);
        $stmt = $conn->prepare("UPDATE tickets SET status='open' WHERE id=?");
        $stmt->bind_param("i", $ticket_id);
        $stmt->execute();
        $stmt->close();
        echo json_encode(['ok'=>1]); exit;
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>مدیریت تیکت‌ها | شیشه‌ای</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700&display=swap">
<style>
body {
  font-family: 'Vazirmatn', 'IRANSans', Tahoma, sans-serif;
  background: radial-gradient(ellipse at 50% 30%, #181f26 60%, #12171e 100%);
  margin: 0;
  min-height: 100vh;
  color: #fff;
  transition: background 0.35s, color 0.35s;
}
[data-theme="light"] body {
  background: radial-gradient(ellipse at 50% 30%, #e8f3ff 60%, #c8e0ff 100%);
  color: #23242a;
}
.ticket-app-frame {
  max-width: 1500px;
  margin: 0 auto;
  padding: 40px 0;
  border-radius: 32px;
  border: 2px solid #23282f;
  background: rgba(24, 28, 33, 0.1);
  box-shadow: 0 0 0 2px rgba(30,40,60,0.2), 0 32px 64px 0 #0a101a99;
  position: relative;
  transition: background 0.4s;
}
[data-theme="light"] .ticket-app-frame {
  background: rgba(255,255,255,0.87);
  border: 2px solid #b8cbe5;
  box-shadow: 0 0 0 2px #b8cbe5, 0 32px 64px 0 #b7d8f4a0;
}
.ticket-app-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
  padding: 0 28px;
}
.ticket-app-title {
  font-size: 2rem;
  font-weight: 700;
  color: #fff;
  margin: 0;
}
[data-theme="light"] .ticket-app-title { color: #23242a; }
.theme-toggle-btn {
  background: #23282f;
  border-radius: 12px;
  color: #fff;
  border: 1.2px solid #23282f;
  font-size: 1.15rem;
  font-weight: 600;
  padding: 9px 28px 7px 28px;
  cursor: pointer;
  outline: none;
  transition: background .17s, color .17s, border .15s;
  margin-right: 0;
  margin-left: 8px;
}
.theme-toggle-btn:hover {
  background: #1ce2eb;
  color: #23282f;
  border-color: #1ce2eb;
}
.ticket-back-btn {
  background: #23282f;
  color: #fff;
  border-radius: 13px;
  font-size: 1.08rem;
  border: 1.2px solid #23282f;
  font-weight: 600;
  padding: 10px 22px 8px 22px;
  cursor: pointer;
  transition: filter .13s, background .16s;
  margin-left: 0;
  margin-right: 8px;
}
.ticket-back-btn:hover {
  filter: brightness(1.10);
  background: #1ce2eb;
  color: #23282f;
  border-color: #1ce2eb;
}
.ticket-app-container {
  display: flex;
  gap: 20px;
  justify-content: center;
}
.ticket-sidebar,
.ticket-details,
.ticket-chat {
  background: rgba(37, 40, 46, 0.92);
  border-radius: 24px;
  border: 2px solid #23282f;
  min-width: 350px;
  min-height: 700px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: stretch;
  transition: background 0.35s;
}
[data-theme="light"] .ticket-sidebar,
[data-theme="light"] .ticket-details,
[data-theme="light"] .ticket-chat {
  background: #f7fbff;
  border: 2px solid #b8cbe5;
}
.ticket-sidebar {
  max-width: 350px;
  width: 350px;
  padding: 0 0 18px 0;
  position: relative;
}
.ticket-sidebar-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 28px 30px 16px 30px;
}
.ticket-sidebar-header h2 {
  font-size: 2rem;
  font-weight: 700;
  margin: 0;
  letter-spacing: -1px;
}
.ticket-list {
  margin: 0;
  padding: 0 30px;
  flex: 1;
  overflow-y: auto;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.ticket-item {
  background: transparent;
  border-radius: 18px;
  border: 1.7px solid #23282f;
  padding: 19px 17px 16px 17px;
  cursor: pointer;
  transition: background .22s, box-shadow .19s;
  margin-bottom: 2px;
  display: flex;
  flex-direction: column;
  gap: 5px;
  position: relative;
}
.ticket-item.selected {
  background: linear-gradient(90deg, #1ce2eb 0%, #15b7c8 100%);
  box-shadow: 0 6px 24px 0 #00fbe380;
  color: #fff;
  border-color: #1ce2eb;
}
.ticket-item.selected .ticket-title,
.ticket-item.selected .ticket-desc,
.ticket-item.selected .ticket-meta,
.ticket-item.selected .ticket-status {
  color: #fff !important;
}
.ticket-title {
  font-weight: 700;
  font-size: 1.1rem;
  margin-bottom: 3px;
  color: #fff;
}
[data-theme="light"] .ticket-title { color: #23242a; }
.ticket-desc {
  font-size: 1rem;
  color: #a5a8b4;
  margin-bottom: 1px;
}
[data-theme="light"] .ticket-desc { color: #5480a7; }
.ticket-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  font-size: 0.97rem;
  color: #b8beca;
  align-items: center;
}
[data-theme="light"] .ticket-meta { color: #5480a7; }
.ticket-status {
  font-size: 1rem;
  border-radius: 8px;
  padding: 0 7px;
  font-weight: 700;
  letter-spacing: -.5px;
}
.ticket-status.open { color: #00e889; }
.ticket-status.closed { color: #ff7171; }
[data-theme="light"] .ticket-status.open { color: #1b8d71; }
[data-theme="light"] .ticket-status.closed { color: #e84e4e; }
.ticket-sidebar-footer {
  margin-top: 16px;
  padding: 0 30px 10px 30px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.ticket-sidebar-footer {
  margin-bottom: 10px;
}
.btn-main,
.ticket-sidebar-footer button {
  width: 100%;
  padding: 13px 0 11px 0;
  background: linear-gradient(90deg,#25e0e8 0%,#11b9cf 100%);
  color: #fff;
  font-weight: 700;
  font-size: 1.1rem;
  border-radius: 16px;
  border: none;
  margin-top: 6px;
  letter-spacing: -.5px;
  cursor: pointer;
  transition: filter .14s, box-shadow .21s, background .23s;
  box-shadow: 0 1px 10px 0 #11b9cf21;
}
.btn-main:hover,
.ticket-sidebar-footer button:hover {
  filter: brightness(1.10);
  box-shadow: 0 6px 30px 0 #1ce2eb3a;
  background: linear-gradient(90deg, #11b9cf 0%, #25e0e8 100%);
}
.ticket-details {
  max-width: 380px;
  width: 380px;
  align-items: center;
  padding: 0 0 18px 0;
}
.ticket-details-header {
  text-align: center;
  padding: 28px 0 16px 0;
  font-size: 1.4rem;
  font-weight: 700;
  color: #fff;
}
[data-theme="light"] .ticket-details-header { color: #23242a; }
.ticket-details-block {
  margin: 0 24px;
  background: rgba(20,22,26,0.85);
  border-radius: 18px;
  border: 1.5px solid #23282f;
  padding: 32px 24px 32px 24px;
  color: #d2d2dd;
  font-size: 1.12rem;
  min-height: 420px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}
[data-theme="light"] .ticket-details-block {
  background: #f2f8fe;
  color: #23242a;
  border: 1.5px solid #b8cbe5;
}
.ticket-details-block b {
  color: #fff;
}
[data-theme="light"] .ticket-details-block b { color: #23242a; }
.ticket-chat {
  flex: 1 1 auto;
  min-width: 420px;
  max-width: 600px;
  align-items: stretch;
  padding: 0 0 18px 0;
}
.ticket-chat-header {
  text-align: center;
  padding: 28px 0 12px 0;
  font-size: 1.4rem;
  font-weight: 700;
  color: #fff;
}
[data-theme="light"] .ticket-chat-header { color: #23242a; }
.ticket-msg-list {
  flex: 1 1 auto;
  padding: 28px 36px 20px 36px;
  min-height: 330px;
  max-height: 420px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 20px;
}
.ticket-msg {
  max-width: 82%;
  min-width: 80px;
  padding: 16px 18px;
  border-radius: 14px;
  font-size: 1.14rem;
  word-break: break-word;
  background: #1ce2eb;
  color: #222;
  align-self: flex-start;
  position: relative;
  box-shadow: 0 1px 18px 0 #1ce2eb30;
}
.ticket-msg.staff {
  background: #23282f;
  color: #fff;
  align-self: flex-end;
  box-shadow: 0 1px 8px 0 #1ce2eb08;
}
[data-theme="light"] .ticket-msg {
  background: #e1fbff;
  color: #23242a;
}
[data-theme="light"] .ticket-msg.staff {
  background: #c4e4fa;
  color: #23242a;
}
.ticket-msg-time {
  font-size: 0.98rem;
  color: #a1e4f5;
  margin-top: 7px;
  opacity: .7;
  text-align: left;
}
.ticket-chat-form-row {
  display: flex;
  align-items: center;
  border-top: 1.5px solid #23282f;
  padding: 18px 36px 0 36px;
  margin-top: auto;
  gap: 9px;
}
[data-theme="light"] .ticket-chat-form-row {
  border-top: 1.5px solid #b8cbe5;
}
.ticket-chat-form-row input[type="text"] {
  background: #23282f;
  border: none;
  border-radius: 16px;
  font-size: 1.1rem;
  color: #fff;
  padding: 13px 18px;
  flex: 1;
  margin-left: 9px;
  outline: none;
  transition: background .14s;
}
[data-theme="light"] .ticket-chat-form-row input[type="text"] {
  background: #f7fbff;
  color: #23242a;
}
.ticket-chat-form-row input[type="text"]:focus {
  background: #29333d;
}
[data-theme="light"] .ticket-chat-form-row input[type="text"]:focus {
  background: #fff;
}
.ticket-chat-form-row button {
  background: #d2d2dd;
  color: #23282f;
  border: none;
  border-radius: 13px;
  font-weight: 700;
  font-size: 1.1rem;
  padding: 12px 34px 10px 34px;
  cursor: pointer;
  transition: filter .15s, background .17s;
}
.ticket-chat-form-row button:hover {
  filter: brightness(1.04);
  background: #fff;
}
::-webkit-scrollbar {width:8px;background:rgba(255,255,255,0.09);border-radius:10px;}
::-webkit-scrollbar-thumb {background: #23282f; border-radius: 10px;}
</style>
</head>
<body>
<div class="ticket-app-frame">
  <div class="ticket-app-header">
    <button class="ticket-back-btn" onclick="window.location='/dashboard'">⟵ بازگشت به داشبورد</button>
    <span class="ticket-app-title">پنل مدیریت تیکت‌ها</span>
    <button class="theme-toggle-btn" id="theme-toggle-btn" title="تغییر حالت روز/شب">🌙</button>
  </div>
  <div class="ticket-app-container">
    <!-- Sidebar -->
    <aside class="ticket-sidebar">
      <div class="ticket-sidebar-header">
        <h2>همه تیکت‌ها</h2>
      </div>
      <ul class="ticket-list" id="ticket-list"></ul>
      <div class="ticket-sidebar-footer">
        <input type="text" id="search-inp" placeholder="جستجو (شناسه، عنوان، کاربر)" style="border-radius:14px;border:1.1px solid #23282f;background:#23282f;color:#fff;padding:11px 18px;font-size:1.05em;font-family:inherit;">
        <button class="btn-main" id="search-btn">جستجو</button>
      </div>
    </aside>
    <!-- Main Chat -->
    <main class="ticket-chat">
      <div class="ticket-chat-header" id="ticket-title">انتخاب تیکت...</div>
      <section class="ticket-msg-list" id="chat-messages"></section>
      <form class="ticket-chat-form-row" id="chat-form" style="display:none">
        <input type="text" id="chat-input" placeholder="پاسخ شما..." autocomplete="off">
        <button type="submit">ارسال پاسخ</button>
      </form>
    </main>
    <!-- Details -->
    <aside class="ticket-details">
      <div class="ticket-details-header">جزئیات تیکت</div>
      <div class="ticket-details-block" id="details-content">
        <p>برای مشاهده جزئیات، یک تیکت را انتخاب کنید.</p>
      </div>
    </aside>
  </div>
</div>
<script>
const ticketList = document.getElementById('ticket-list');
const chatMessages = document.getElementById('chat-messages');
const chatForm = document.getElementById('chat-form');
const chatInput = document.getElementById('chat-input');
const ticketTitle = document.getElementById('ticket-title');
const detailsContent = document.getElementById('details-content');
const searchInp = document.getElementById('search-inp');
const searchBtn = document.getElementById('search-btn');
let currentTicketId = null, lastUser = null, ticketStatus = 'open';
// ---- Theme toggle ----
const themeToggleBtn = document.getElementById('theme-toggle-btn');
const htmlEl = document.documentElement;
function setTheme(mode) {
  if(mode==='light') {
    htmlEl.setAttribute('data-theme','light');
    themeToggleBtn.innerHTML = "🌞";
  } else {
    htmlEl.setAttribute('data-theme','dark');
    themeToggleBtn.innerHTML = "🌙";
  }
  localStorage.setItem('ticket_theme',mode);
}
themeToggleBtn.onclick = function() {
  let mode = htmlEl.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
  setTheme(mode);
};
(function() {
  let mode = localStorage.getItem('ticket_theme');
  if (mode && mode!=='dark') setTheme(mode);
  else setTheme('dark');
})();
// ---- Load Tickets ----
searchBtn.onclick = ()=>{ loadTickets(); };
searchInp.onkeydown = e=>{ if(e.key==='Enter'){searchBtn.click();} };
async function loadTickets(selectedTicket) {
  let searchVal = searchInp.value;
  let res = await fetch('?api=tickets'+(searchVal?'&search='+encodeURIComponent(searchVal):''));
  let list = await res.json();
  ticketList.innerHTML = '';
  if(list.length===0) ticketList.innerHTML='<div style="color:#a5a8b4;text-align:center;padding:22px;">هیچ تیکتی یافت نشد.</div>';
  list.forEach(t=>{
    let li = document.createElement('li');
    li.className = 'ticket-item'+(t.id==selectedTicket?' selected':'');
    li.innerHTML = `<div class="ticket-title">${t.title}</div>
      <div class="ticket-meta">
        <span class="ticket-status ${t.status}">${t.status==='open'?'باز':'بسته'}</span>
        <span>پیام: ${t.msg_count}</span>
        <span>کاربر: <b style="color:#1ce2eb">${t.user}</b></span>
        <span>${t.date}</span>
      </div>`;
    li.onclick = ()=>showTicket(t.id, t.user);
    ticketList.appendChild(li);
  });
  if(selectedTicket && list.some(t=>t.id==selectedTicket)) showTicket(selectedTicket);
}
// ---- Show Ticket and Chat ----
async function showTicket(id, username) {
  currentTicketId = id;
  [...ticketList.children].forEach(li=>li.classList.remove('selected'));
  let tli = [...ticketList.children].find(l=>l.textContent.includes(id));
  if(tli) tli.classList.add('selected');
  let tinfo = await fetch(`?api=ticket_details&ticket_id=${id}`).then(r=>r.json());
  ticketStatus = tinfo.status;
  ticketTitle.textContent = tinfo.title+' | توسط '+tinfo.user;
  detailsContent.innerHTML = `
    <b>عنوان:</b> ${tinfo.title}<br>
    <span><b>شناسه:</b> ${tinfo.id}</span><br>
    <span><b>توسط:</b> <span style="color:#1ce2eb;font-weight:700">${tinfo.user}</span></span><br>
    <span><b>تاریخ ثبت:</b> ${tinfo.created_at}</span><br>
    <span><b>وضعیت:</b> <span style="color:${tinfo.status==='open'?'#00e889':'#ff7171'}">${tinfo.status==='open'?'باز':'بسته'}</span></span><br>
    <span><b>تعداد پیام‌ها:</b> ${tinfo.msg_count}</span>
    <br>
    <button id="close-ticket-btn" class="btn-main" style="margin-top:12px;${tinfo.status==='closed'?'display:none;':''}">بستن تیکت</button>
    <button id="open-ticket-btn" class="btn-main" style="margin-top:12px;${tinfo.status==='open'?'display:none;':''}">بازکردن تیکت</button>
  `;
  let closeBtn = document.getElementById('close-ticket-btn');
  if(closeBtn) closeBtn.onclick = async function() {
    await fetch('?api=close_ticket', {method:'POST', body: new URLSearchParams({ticket_id:id})});
    await loadTickets(id);
    showTicket(id, tinfo.user);
  };
  let openBtn = document.getElementById('open-ticket-btn');
  if(openBtn) openBtn.onclick = async function() {
    await fetch('?api=open_ticket', {method:'POST', body: new URLSearchParams({ticket_id:id})});
    await loadTickets(id);
    showTicket(id, tinfo.user);
  };
  let res = await fetch(`?api=messages&ticket_id=${id}`);
  let msgs = await res.json();
  chatMessages.innerHTML = '';
  lastUser = tinfo.user;
  msgs.forEach((m,i)=>{
    let div = document.createElement('div');
    div.className = 'ticket-msg '+(m.sender_type==='user'?'':'staff');
    div.innerHTML = `<span>${m.message}</span>
      <div class="ticket-msg-time">${m.time}</div>`;
    chatMessages.appendChild(div);
  });
  chatMessages.scrollTop = chatMessages.scrollHeight;
  chatForm.style.display = (tinfo.status === 'open') ? '' : 'none';
}
// ---- Send Message ----
chatForm.onsubmit = async function(e) {
  e.preventDefault();
  if(!currentTicketId || ticketStatus !== 'open') return;
  let txt = chatInput.value.trim();
  if(!txt) return;
  await fetch('?api=send_message', {
    method: 'POST',
    body: new URLSearchParams({ticket_id:currentTicketId, message:txt})
  });
  chatInput.value = '';
  showTicket(currentTicketId, lastUser);
};
loadTickets();
</script>
</body>
</html>