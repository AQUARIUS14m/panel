<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
header('Content-Type: application/json; charset=utf-8');

// --- API چت ---
if (isset($_GET['action'])) {
    $username = $_SESSION['player_username'] ?? 'TestUser';
    require __DIR__ . '/db.php';

    $action = $_GET['action'];
    if ($action === 'send' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $text = trim($_POST['text'] ?? '');
        if ($text === '' || mb_strlen($text) > 350) {
            echo json_encode(['error' => 'پیام نامعتبر']);
            exit;
        }
        $text = htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8");
        $stmt = $conn->prepare("INSERT INTO Chat_live (username, text) VALUES (?, ?)");
        $stmt->bind_param('ss', $username, $text);
        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['error' => $stmt->error]);
        }
        $stmt->close();
        exit;
    }
    elseif ($action === 'fetch') {
        $limit = 60;
        $result = $conn->query("SELECT username, text, DATE_FORMAT(created_at, '%H:%i') as time FROM Chat_live ORDER BY id DESC LIMIT $limit");
        $rows = [];
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
        $rows = array_reverse($rows);
        echo json_encode($rows, JSON_UNESCAPED_UNICODE);
        exit;
    }
    echo json_encode(['error' => 'عملیات نامعتبر']);
    exit;
}

// --- اگر پارامتر action نبود، صفحه چت را نمایش بده ---
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>چت واتساپی آنلاین</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --main-blue: #2196f3;
      --main-blue-dark: #1566a3;
      --main-bg: #f0f6ff;
      --main-bg-dark: #19202b;
      --msg-bg: #2196f3;
      --msg-bg-night: #1566a3;
      --msg-color: #fff;
      --border: #d0e5ff;
      --border-dark: #264263;
      --avatar-bg: #eaf4fb;
      --avatar-bg-dark: #23344c;
      --input-bg: #fff;
      --input-bg-dark: #22304a;
      --header-bg: #2196f3;
      --header-bg-dark: #19202b;
      --header-color: #fff;
      --switch-bg: #e9f5ff;
      --switch-bg-dark: #23344c;
      --switch-knob: #41c2ff;
      --switch-knob-dark: #2196f3;
      --chat-scroll-thumb: #8fd6ff;
      --chat-scroll-thumb-dark: #2196f3;
    }
    body {
      background: var(--main-bg);
      min-height: 100vh;
      margin: 0;
      font-family: 'Vazirmatn', Tahoma, Arial, sans-serif;
      color: #1c283b;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      transition: background 0.3s;
    }
    body.night {
      background: var(--main-bg-dark);
      color: #e6f2ff;
    }
    .chat-container {
      width: 99vw;
      max-width: 1000px;
      height: 90vh;
      min-height: 600px;
      background: #fafdff;
      border-radius: 30px;
      margin: 32px 0;
      box-shadow: 0 8px 32px #2196f377, 0 0 0 6px #2196f310;
      display: flex;
      flex-direction: column;
      border: 2.2px solid var(--border);
      overflow: hidden;
      position: relative;
      z-index: 10;
      transition: background 0.3s, border 0.3s, box-shadow 0.3s;
    }
    body.night .chat-container {
      background: #1d273b;
      border: 2.2px solid var(--border-dark);
      box-shadow: 0 12px 64px #0af2ff55, 0 0 0 12px #0af2ff10;
    }
    .chat-header {
      background: var(--header-bg);
      color: var(--header-color);
      font-size: 1.25rem;
      font-weight: bold;
      padding: 28px 40px 18px 24px;
      border-bottom: 2px solid var(--border);
      box-shadow: 0 2px 20px #2196f322;
      display: flex;
      align-items: center;
      gap: 10px;
      position: relative;
      z-index: 2;
      user-select: none;
    }
    body.night .chat-header {
      background: var(--header-bg-dark);
      color: #fff;
      box-shadow: 0 2px 24px #0af2ff33;
      border-bottom: 2px solid var(--border-dark);
    }
    .back-btn {
      background: #fff;
      color: #2196f3;
      border: none;
      border-radius: 8px;
      font-size: 1.06rem;
      padding: 7px 18px 7px 18px;
      font-family: inherit;
      cursor: pointer;
      margin-left: 18px;
      transition: background 0.2s, color 0.2s, box-shadow 0.2s;
      box-shadow: 0 2px 8px #2196f322;
      font-weight: bold;
    }
    .back-btn:hover {
      background: #2196f3;
      color: #fff;
      box-shadow: 0 2px 16px #2196f399;
    }
    body.night .back-btn {
      background: #23344c;
      color: #fff;
      box-shadow: 0 2px 10px #41c2ff44;
    }
    .header-switch {
      margin-right: auto;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    /* Better theme toggle - two buttons */
    .theme-toggle-group {
      display: flex;
      border-radius: 12px;
      overflow: hidden;
      border: 1.2px solid #8fd6ff;
      background: #eaf6ff;
      box-shadow: 0 1px 6px #2196f322;
    }
    .theme-toggle-btn {
      appearance: none;
      border: none;
      background: none;
      outline: none;
      padding: 7px 18px;
      font-size: 1.15rem;
      font-weight: bold;
      cursor: pointer;
      color: #2196f3;
      transition: background 0.18s, color 0.18s;
    }
    .theme-toggle-btn.active,
    .theme-toggle-btn:hover {
      background: #2196f3;
      color: #fff;
    }
    body.night .theme-toggle-group {
      background: #23344c;
      border: 1.2px solid #41c2ff;
    }
    body.night .theme-toggle-btn {
      color: #8fd6ff;
    }
    body.night .theme-toggle-btn.active,
    body.night .theme-toggle-btn:hover {
      background: #1566a3;
      color: #fff;
    }
    .chat-messages {
      flex: 1;
      padding: 42px 36px 18px 32px;
      overflow-y: auto;
      background: transparent;
      display: flex;
      flex-direction: column;
      gap: 16px;
      min-height: 300px;
      max-height: 99%;
    }
    .chat-message-row {
      display: flex;
      align-items: flex-end;
      margin-bottom: 2px;
      gap: 11px;
    }
    .chat-message-row.me {
      flex-direction: row-reverse;
    }
    .avatar {
      width: 44px;
      height: 44px;
      background: var(--avatar-bg);
      color: #1c9dea;
      border-radius: 50%;
      font-size: 1.19rem;
      font-weight: bold;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 1px 11px #0af2ff44;
      margin-bottom: 8px;
      user-select: none;
      border: 2px solid #41c2ff;
      transition: background 0.3s, border 0.3s, color 0.3s;
    }
    body.night .avatar {
      background: var(--avatar-bg-dark);
      border: 2px solid #2196f3;
      color: #0af2ff;
    }
    .chat-bubble {
      max-width: 80vw;
      padding: 18px 28px 15px 23px;
      border-radius: 16px 16px 8px 16px;
      background: var(--msg-bg);
      color: var(--msg-color);
      border: 1.6px solid #2196f3;
      font-size: 1.15rem;
      word-break: break-word;
      animation: bubbleIn .27s;
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      transition: background 0.3s, color 0.3s, border 0.3s;
      filter: none;
      box-shadow: 0 1px 9px #2196f344;
    }
    body.night .chat-bubble {
      background: var(--msg-bg-night);
      color: #fff;
      border: 1.6px solid #41c2ff;
    }
    .chat-message-row.me .chat-bubble {
      background: var(--msg-bg);
      color: var(--msg-color);
      border: 1.6px solid #41c2ff;
      align-items: flex-end;
    }
    body.night .chat-message-row.me .chat-bubble {
      background: var(--msg-bg-night);
      color: #fff;
      border: 1.6px solid #8fd6ff;
    }
    .chat-bubble:hover {
      box-shadow: 0 4px 16px #2196f355, 0 0 7px #0af2ff22;
      border: 1.7px solid #41c2ff;
      background: #1566a3;
      color: #fff;
    }
    body.night .chat-bubble:hover {
      background: #0e2542;
      color: #fff;
      border: 1.7px solid #8fd6ff;
    }
    @keyframes bubbleIn {
      from { opacity: 0; transform: scale(.96) translateY(14px);}
      to   { opacity: 1; transform: scale(1) translateY(0);}
    }
    .bubble-header {
      font-weight: bold;
      color: #fff;
      font-size: 1.07rem;
      margin-bottom: 7px;
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .bubble-time {
      color: #fff;
      font-size: .97rem;
      margin-right: 11px;
      margin-left: 0;
      font-family: monospace;
      letter-spacing: 0.3px;
    }
    .chat-message-row.me .bubble-header {
      flex-direction: row-reverse;
      color: #fff;
    }
    .chat-message-row.me .bubble-time {
      margin-left: 11px;
      margin-right: 0;
      color: #fff;
    }
    .bubble-text {
      color: inherit;
      font-size: 1.18rem;
      line-height: 2.05;
    }
    .chat-form {
      display: flex;
      padding: 20px 38px 28px 28px;
      gap: 16px;
      align-items: center;
      border-top: 1.8px solid var(--border);
      background: var(--main-bg);
      box-shadow: 0 -2px 11px #2196f322;
      transition: background 0.3s, border 0.3s;
      z-index: 2;
    }
    body.night .chat-form {
      background: #14294a;
      border-top: 1.8px solid #1b3558;
      box-shadow: 0 -2px 22px #2196f344;
    }
    .chat-input {
      flex: 1;
      padding: 17px 25px;
      border: 1.7px solid var(--border);
      border-radius: 15px;
      font-size: 1.15rem;
      background: var(--input-bg);
      outline: none;
      font-family: inherit;
      color: #2f446c;
      transition: border .15s, background .2s, color .2s;
      box-shadow: 0 1px 12px #2196f311;
    }
    body.night .chat-input {
      background: var(--input-bg-dark);
      color: #e6f2ff;
      border: 1.7px solid #2196f3;
      box-shadow: 0 1px 15px #2196f344;
    }
    .chat-input:focus {
      border: 2px solid #2196f3;
      background: #eaf4ff;
    }
    body.night .chat-input:focus {
      border: 2px solid #0af2ff;
      background: #19202b;
      color: #0af2ff;
    }
    .chat-send {
      background: #2196f3;
      color: #fff;
      border: none;
      border-radius: 13px;
      padding: 14px 34px;
      font-size: 1.15rem;
      font-weight: bold;
      cursor: pointer;
      box-shadow: 0 2px 17px #2196f333, 0 0 0 #0af2ff00;
      letter-spacing: .18px;
      position: relative;
      z-index: 2;
      transition: background .13s, color .13s, box-shadow 0.2s;
      outline: none;
    }
    .chat-send:hover, .chat-send:focus {
      background: #1566a3;
      color: #fff;
      box-shadow: 0 2px 21px #0af2ff99, 0 0 12px #0af2ff55;
      outline: none;
    }
    .chat-messages::-webkit-scrollbar { width: 11px; background: #e5e5e5;}
    .chat-messages::-webkit-scrollbar-thumb { background: var(--chat-scroll-thumb); border-radius: 8px;}
    body.night .chat-messages::-webkit-scrollbar-thumb { background: var(--chat-scroll-thumb-dark);}
    @media (max-width: 900px) {
      .chat-container { max-width: 99vw; }
      .chat-messages, .chat-form { padding-left: 2vw; padding-right: 2vw;}
      .chat-header { padding: 14px 3vw 12px 2vw;}
    }
    @media (max-width: 600px) {
      .chat-container { max-width: 99vw; height: 99vh; border-radius: 0; margin:0;}
      .chat-header { font-size: 1.09rem; padding: 7px 2vw 12px 1vw;}
      .chat-form { padding: 9px 2vw 9px 2vw;}
      .chat-messages { padding: 6px 2vw 6px 2vw; }
      .avatar { width: 30px; height: 30px; font-size: .98rem;}
    }
  </style>
</head>
<body>
  <div class="chat-container">
    <div class="chat-header">
      <button class="back-btn" onclick="window.location.href='/dashboard'">⬅ بازگشت به داشبورد</button>
      <span class="icon">💬</span>
      چت آنلاین
      <div class="header-switch">
        <div class="theme-toggle-group">
          <button id="light-btn" class="theme-toggle-btn" type="button">☀️ روز</button>
          <button id="dark-btn" class="theme-toggle-btn" type="button">🌙 شب</button>
        </div>
      </div>
    </div>
    <div class="chat-messages" id="chat-messages"></div>
    <form class="chat-form" id="chat-form" autocomplete="off">
      <input type="text" class="chat-input" id="chat-input" maxlength="350" placeholder="پیام خود را بنویسید..." required>
      <button class="chat-send" type="submit">ارسال</button>
    </form>
  </div>
  <script>
    // --- تم شب و روز بهتر ---
    const lightBtn = document.getElementById('light-btn');
    const darkBtn = document.getElementById('dark-btn');
    function setTheme(mode){
      if(mode==='night'){
        document.body.classList.add('night');
        lightBtn.classList.remove('active');
        darkBtn.classList.add('active');
      }else{
        document.body.classList.remove('night');
        darkBtn.classList.remove('active');
        lightBtn.classList.add('active');
      }
      localStorage.setItem('chat-theme', mode);
    }
    lightBtn.onclick = ()=>setTheme('day');
    darkBtn.onclick = ()=>setTheme('night');
    // Init
    (function(){
      let mode = localStorage.getItem('chat-theme');
      setTheme(mode==='night'?'night':'day');
    })();

    // نام کاربری فعلی از PHP (یا سشن)
    const currentUsername = "<?= htmlspecialchars($_SESSION['player_username'] ?? 'TestUser') ?>";
    function getAvatarLetter(name) {
      if(!name) return "?";
      return name.toUpperCase().charAt(0);
    }

    // نمایش پیام‌ها
    const chatMessages = document.getElementById('chat-messages');
    async function fetchMessages() {
      const res = await fetch('chat.php?action=fetch');
      const data = await res.json();
      chatMessages.innerHTML = '';
      data.forEach(msg => {
        const isMe = msg.username === currentUsername;
        chatMessages.innerHTML += `
          <div class="chat-message-row${isMe ? ' me' : ''}">
            <div class="avatar">${getAvatarLetter(msg.username)}</div>
            <div class="chat-bubble">
              <div class="bubble-header">
                <span>${escapeHTML(msg.username)}</span>
                <span class="bubble-time">${escapeHTML(msg.time)}</span>
              </div>
              <div class="bubble-text">${escapeHTML(msg.text)}</div>
            </div>
          </div>
        `;
      });
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // ارسال پیام
    const chatForm = document.getElementById('chat-form');
    const chatInput = document.getElementById('chat-input');
    chatForm.addEventListener('submit', async e => {
      e.preventDefault();
      const text = chatInput.value.trim();
      if(!text) return;
      chatInput.value = '';
      await fetch('chat.php?action=send', {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: 'text=' + encodeURIComponent(text)
      });
      fetchMessages();
    });
    setInterval(fetchMessages, 2000);
    fetchMessages();

    // ضد XSS
    function escapeHTML(str) {
      return str.replace(/[&<>"']/g, m =>
        ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m])
      );
    }
  </script>
</body>
</html>