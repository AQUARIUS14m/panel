<?php
session_start();
require_once "db.php";
if (!isset($_SESSION['player_logged_in']) || !$_SESSION['player_logged_in']) {
    header("Location: player_login.php");
    exit();
}
$username = $_SESSION['player_username'];

// توابع کمکی
function format_fa_num($num) {
    return str_replace(range(0,9), ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'], $num);
}
function extract_rank_name($rank_json) {
    if(!$rank_json) return 'بدون رنک';
    $arr = @json_decode($rank_json, true);
    if(is_array($arr) && count($arr)) {
        return array_keys($arr)[0];
    }
    return 'بدون رنک';
}
function minecraft_colored_rank($rank) {
    $mc_colors = [
        '0'=>'#000000','1'=>'#0000AA','2'=>'#00AA00','3'=>'#00AAAA',
        '4'=>'#AA0000','5'=>'#AA00AA','6'=>'#FFAA00','7'=>'#AAAAAA',
        '8'=>'#555555','9'=>'#5555FF','a'=>'#55FF55','b'=>'#55FFFF',
        'c'=>'#FF5555','d'=>'#FF55FF','e'=>'#FFFF55','f'=>'#FFFFFF'
    ];
    $bold = false; $italic = false; $under = false; $obf = false;
    $out = '';
    $color = null;
    $i=0;
    $len = mb_strlen($rank);
    while($i < $len) {
        $ch = mb_substr($rank, $i, 1);
        if($ch === '§' && $i+1<$len) {
            $i++;
            $code = mb_substr($rank, $i, 1);
            if(isset($mc_colors[strtolower($code)])) {
                $color = $mc_colors[strtolower($code)];
                $bold = $italic = $under = $obf = false;
                $out .= '<span style="color:'.$color.'">';
            } elseif($code==='l') {
                $bold = true;
                $out .= '<span style="font-weight:bold">';
            } elseif($code==='o') {
                $italic = true;
                $out .= '<span style="font-style:italic">';
            } elseif($code==='n') {
                $under = true;
                $out .= '<span style="text-decoration:underline">';
            } elseif($code==='m') {
                $out .= '<span style="text-decoration:line-through">';
            } elseif($code==='r') {
                $color = null; $bold = $italic = $under = $obf = false;
                $out .= '</span>';
            }
        } else {
            $out .= htmlspecialchars($ch);
        }
        $i++;
    }
    $out .= str_repeat('</span>', substr_count($out, '<span') - substr_count($out, '</span>'));
    return $out;
}

// اطلاعات کاربری
$stmt = $conn->prepare("SELECT * FROM users WHERE username=?");
if (!$stmt) die("Prepare failed (users): " . $conn->error);
$stmt->bind_param("s", $username);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$user) die("<div style='color:red;text-align:center;margin-top:40px;font-size:1.4em'>خطا: اطلاعات کاربری یافت نشد. لطفاً دوباره وارد شوید.</div>");
$avatar = "logo.png";
$last_login = $user['last_login'] ?? "-";
$created_at = $user['created_at'] ?? "-";

// گرفتن id کاربر برای money و novacoin
$stmt_userid = $conn->prepare("SELECT id FROM users WHERE username=?");
if (!$stmt_userid) die("Prepare failed (userid): " . $conn->error);
$stmt_userid->bind_param("s", $username);
$stmt_userid->execute();
$res_uid = $stmt_userid->get_result();
$user_id = null;
if($row = $res_uid->fetch_assoc()) $user_id = $row['id'];
$stmt_userid->close();

// NovaCoin
$novacoin = 0;
$stmt_coin = $conn->prepare("SELECT coins FROM novacoin WHERE username=?");
if (!$stmt_coin) die("Prepare failed (novacoin): " . $conn->error);
$stmt_coin->bind_param("s", $username);
$stmt_coin->execute();
$res_coin = $stmt_coin->get_result();
if ($row_coin = $res_coin->fetch_assoc()) $novacoin = intval($row_coin['coins']);
$stmt_coin->close();

// مقدار پول
$money = 0;
if($user_id) {
    $stmt_money = $conn->prepare("SELECT amount FROM money WHERE user_id=?");
    if (!$stmt_money) die("Prepare failed (money): " . $conn->error);
    $stmt_money->bind_param("i", $user_id);
    $stmt_money->execute();
    $result_money = $stmt_money->get_result();
    if ($row_money = $result_money->fetch_assoc()) $money = intval($row_money['amount']);
    $stmt_money->close();
}

// ایمیل و موبایل
$registered_email = "";
$registered_phone = "";
$stmt_em = $conn->prepare("SELECT email, mobile FROM emails WHERE username=? ORDER BY id DESC LIMIT 1");
if (!$stmt_em) die("Prepare failed (emails): " . $conn->error);
$stmt_em->bind_param("s", $username);
$stmt_em->execute();
$res_em = $stmt_em->get_result();
if($row_em = $res_em->fetch_assoc()) {
    $registered_email = $row_em['email'];
    $registered_phone = $row_em['mobile'];
}
$stmt_em->close();

// رنک و پرمیشن دیتابیس رنک سیستم
$my_ranksystem_rank = "بدون رنک";
$my_ranksystem_perms = "-";
$stmt_rank = $conn->prepare("SELECT ranks, permissions FROM ranksystemusers WHERE name=?");
if (!$stmt_rank) die("Prepare failed (ranksystemusers): " . $conn->error);
$stmt_rank->bind_param("s", $username);
$stmt_rank->execute();
$res_rank = $stmt_rank->get_result();
if($row_rank = $res_rank->fetch_assoc()) {
    $my_ranksystem_rank = $row_rank['ranks'];
    $my_ranksystem_perms = $row_rank['permissions'];
}
$stmt_rank->close();
$my_ranksystem_rank_name = extract_rank_name($my_ranksystem_rank);

// بررسی پیام جدید از ساپورتر
$supporters = ['Staff1','Staff2','MohammadMety']; // لیست ساپورترها
$stmt = $conn->prepare("SELECT id FROM chat_conversations WHERE user=? AND status='open' ORDER BY id DESC LIMIT 1");
if (!$stmt) die("Prepare failed (chat_conversations): " . $conn->error);
$stmt->bind_param("s", $username);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();

$new_support_msg = false;
$support_msg_text = "";
if ($row) {
    $conversation_id = $row['id'];
    $stmt = $conn->prepare("SELECT sender, message FROM chat_messages WHERE conversation_id=? ORDER BY sent_at DESC LIMIT 1");
    if (!$stmt) die("Prepare failed (chat_messages): " . $conn->error);
    $stmt->bind_param("i", $conversation_id);
    $stmt->execute();
    $msg = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($msg && in_array($msg['sender'], $supporters)) {
        $new_support_msg = true;
        $support_msg_text = $msg['message'];
    }
}

// چک رنک کاربر برای منوی پیشرفته
$allowed_roles = ['Owner','Admin','§aMan§rager','Manager','Manrager']; // همه اسامی محتمل رنک منیجر!
$user_role = $my_ranksystem_rank_name;

// برای نشان دادن تعداد تیکت‌های باز (برای نقش بالاتر)
$open_tickets_count = 0;
if (in_array($user_role, $allowed_roles)) {
    $res = $conn->query("SELECT COUNT(*) as c FROM tickets WHERE status='open'");
    if ($row = $res->fetch_assoc()) $open_tickets_count = $row['c'];
}

// تعداد پیام‌های جدید تیکت برای پلیر (اختیاری: اگر سیستم تیکت داری)
$new_messages = 0;
$stmt_msg = $conn->prepare("SELECT COUNT(*) as c FROM tickets WHERE user=? AND status='open'");
if (!$stmt_msg) die("Prepare failed (tickets): " . $conn->error);
$stmt_msg->bind_param("s", $username);
$stmt_msg->execute();
$res_msg = $stmt_msg->get_result();
if($row_msg = $res_msg->fetch_assoc()) $new_messages = $row_msg['c'];
$stmt_msg->close();

// وضعیت بن
$ban_account = false;
$play_time = "22 دقیقه 41 ثانیه";

// تایم پلی سرورها
$play_times = [
    "لابی"       => ['minutes' => 5,  'seconds' => 0],
    "سروایول"    => ['minutes' => 10, 'seconds' => 0],
    "اسکای بلاک" => ['minutes' => 4, 'seconds' => 0],
    "آرکید"      => ['minutes' => 1,  'seconds' => 0],
    "بدوارز"     => ['minutes' => 0,  'seconds' => 0],
    "بتل رویال"  => ['minutes' => 0,  'seconds' => 0]
];

// تعداد چت‌های باز همه کاربران (فقط برای نقش‌های مجاز)
$open_chats_count = 0;
if (in_array($user_role, $allowed_roles)) {
    $res = $conn->query("SELECT COUNT(*) as c FROM chat_conversations WHERE status='open'");
    if ($row = $res->fetch_assoc()) $open_chats_count = $row['c'];
}
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>داشبورد پلیر</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="logo.png">
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <style>
        :root {
    --primary: #c0c0c0;
    --accent: #bcbcbc;
    --accent2: #bcbcbc;
    --accent-hover: #e8e8e8;
    --danger: #ff6363;
    --success: #44e895;
    --blue: #5bb6ff;
    --glass: rgba(255,255,255,0.05);
    --glass-border: rgba(255,255,255,0.13);
    --box-radius: 20px;
}
body {
    background: linear-gradient(120deg, #181a23 0%, #23243a 100%);
    color: var(--primary);
    font-family: 'Vazirmatn', sans-serif;
    margin: 0;
    padding: 0;
    min-height: 100vh;
    direction: rtl;
}
.dashboard-container {
    display: flex;
    min-height: 100vh;
}
.sidebar {
    width: 270px;
    background: #23242a;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 32px 0 0 0;
    box-shadow: 2px 0 22px #0002;
    position: sticky;
    top: 0;
    min-height: 100vh;
    z-index: 3;
}
.sidebar .avatar {
    width: 88px;
    height: 88px;
    border-radius: 24px;
    object-fit: cover;
    border: 3px solid var(--accent);
    box-shadow: 0 2px 18px #c0c0c080;
}
.sidebar .username {
    margin-top: 18px;
    font-size: 1.25rem;
    font-weight: bold;
    color: var(--accent);
    text-shadow: 0 2px 8px #0003;
}
.sidebar .user-rank {
    margin: 8px 0 12px 0;
    font-size: 1em;
    font-weight: bold;
    background: var(--glass);
    border-radius: 10px;
    padding: 6px 18px;
    box-shadow: 0 1px 8px #c0c0c040;
    letter-spacing: .5px;
    line-height: 2.1em;
    min-height: 2.1em;
    display: inline-block;
    text-align: center;
    word-break: break-all;
    max-width: 170px;
}
.sidebar-contact {
    font-size: 1.01rem;
    color: var(--primary);
    background: var(--glass);
    border-radius: 10px;
    padding: 7px 15px;
    margin-bottom: 10px;
    margin-top: 4px;
    direction: ltr;
    text-align: left;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 7px;
}
.sidebar-contact i { color: var(--accent2); font-size: 1.13em;}
.sidebar-menu { width: 100%; margin-top: 24px;}
.sidebar-menu ul { list-style: none; padding: 0; margin: 0;}
.sidebar-menu li {margin:0;}
.sidebar-menu a {
    display: flex;
    align-items: center;
    color: var(--primary);
    padding: 13px 24px 13px 18px;
    text-decoration: none;
    transition: all .22s;
    font-size: 1.09rem;
    border-right: 4px solid transparent;
    position: relative;
    border-radius: 7px 0 0 7px;
}
.sidebar-menu a i {
    font-size: 1.19rem;
    margin-left: 10px;
}
.sidebar-menu a.active,
.sidebar-menu a:hover {
    background: var(--glass);
    color: var(--accent-hover);
    border-right: 4px solid var(--accent2);
}
.sidebar-menu .badge {
    background: var(--accent2);
    color: #23243a;
    font-size: .81em;
    border-radius: 8px;
    padding: 2px 8px;
    margin-right: 10px;
}
.sidebar-footer {
    margin-top: 33px;
    font-size: 0.97em;
    opacity: 0.7;
}
.sidebar-footer a {
    color: var(--accent2);
    text-decoration: none;
    transition: color .16s;
}
.sidebar-footer a:hover { color: var(--accent-hover);}
.logout-btn {
    margin: 30px 0 0 0;
    padding: 12px 0;
    background: linear-gradient(90deg,#ccc 60%,#888 100%);
    color: #23243a;
    font-size: 1.13em;
    border: none;
    border-radius: 11px;
    font-weight: bold;
    box-shadow: 0 4px 22px #b0b0b009;
    cursor: pointer;
    transition: background .22s, color .19s, transform .18s;
    letter-spacing: .4px;
    outline: none;
    width: 90%;
    display: block;
}
.logout-btn:hover {
    background: linear-gradient(90deg,#888 30%,#fff 100%);
    color: #23243a;
    transform: scale(1.04);
}
.main-content {
    flex: 1;
    padding: 38px 3vw 50px 3vw;
    background: none;
    z-index: 1;
    position: relative;
}
.welcome-card {
    background: var(--glass);
    border-radius: var(--box-radius);
    padding: 26px 38px 26px 18px;
    margin-bottom: 28px;
    display: flex;
    align-items: center;
    gap: 38px;
    box-shadow: 0 2px 18px #0002;
    border: 1px solid var(--glass-border);
}
.welcome-img { width: 92px; margin-right: 18px;}
.welcome-text h2 { color: var(--accent2); font-size: 1.36rem; margin-bottom: 8px; font-weight: bold;}
.welcome-text h3 { margin: 0; font-size: 1.09rem; color: #fff; opacity: 0.95; font-weight: 400;}
.profile-card {
    background: var(--glass);
    border-radius: 18px;
    padding: 24px 22px 12px 22px;
    margin-bottom: 25px;
    box-shadow: 0 2px 18px #0002;
    display: flex;
    flex-wrap: wrap;
    gap: 35px 22px;
    align-items: flex-start;
    border: 1px solid var(--glass-border);
}
.profile-info { flex: 1 1 220px; }
.profile-info-row { margin-bottom: 10px; font-size: 1.09rem; color: var(--primary); display: flex; align-items: center;}
.dashboard-row {
    display: flex;
    flex-wrap: wrap;
    gap: 23px;
    margin-bottom: 20px;
}
.dashboard-box {
    background: var(--glass);
    border-radius: var(--box-radius);
    min-width: 190px;
    flex: 1 1 180px;
    max-width: 310px;
    padding: 18px 0 18px 0;
    text-align: center;
    box-shadow: 0 2px 18px #0002;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    border: 1.5px solid var(--glass-border);
    margin-bottom: 12px;
    transition: transform .18s;
}
.dashboard-box:hover {
    transform: scale(1.04) translateY(-4px);
    box-shadow: 0 8px 36px #bcbcbc44;
}
.dashboard-box .title {
    color: var(--accent2);
    margin-bottom: 10px;
    font-size: 1.13em;
    font-weight: 700;
    letter-spacing: .1px;
}
.dashboard-stat .label {
    color: #b0b0b0;
    font-size: 1.02em;
    font-weight: 500;
    margin-bottom: 4px;
    letter-spacing: .15px;
}
.dashboard-stat .value {
    font-size: 1.7em;
    font-weight: bold;
    color: var(--primary);
    display: flex;
    align-items: center;
    gap: 7px;
    margin-bottom: 2px;
}
.dashboard-stat .value.money { color: var(--success); }
.dashboard-stat .value.novacoin { color: var(--accent2);}
.dashboard-stat .value.rank { color: var(--accent2);}
.dashboard-stat .value.success { color: var(--success);}
.dashboard-stat .value.danger { color: var(--danger);}
.dashboard-stat .value.blue { color: var(--blue);}
.dashboard-stat i { margin-right: 2px; font-size: 1.18em;}
/* باکس رنک خاص */
.dashboard-box.rank-box .pretty-rank-wrapper {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 9px;
    padding: 6px 0;
}
.pretty-rank {
    font-weight: bold;
    color: #c0c0c0;
    padding: 3px 22px;
    border-radius: 16px;
    background: linear-gradient(90deg,#282828 65%,#bcbcbc60 100%);
    box-shadow: 0 2px 14px #bcbcbc33, 0 1px 0 #fff2;
    font-size: 1.24em;
    letter-spacing: .9px;
    animation: shine-rank 1.7s infinite alternate;
    border: 1.5px solid #bcbcbc77;
    text-shadow: 0 2px 8px #f4f4f4cc;
}
.dashboard-box.rank-box .bxs-crown {
    color: #bcbcbc;
    font-size: 1.5em;
    filter: drop-shadow(0 2px 8px #bcbcbc66);
    margin-top: -3px;
}
@keyframes shine-rank {
    0% { text-shadow:0 0 10px #fffbe6, 0 0 20px #bcbcbc44;}
    100% { text-shadow:0 0 18px #bcbcbcab, 0 0 32px #fffbe6bb;}
}
.playtime-box {
    background: var(--glass);
    border-radius: 16px;
    margin: 34px auto 0 auto;
    padding: 24px 32px 17px 32px;
    max-width: 480px;
    box-shadow: 0 2px 14px #bcbcbc22;
    border: 1.5px solid var(--glass-border);
    color: var(--primary);
    font-size: 1.08em;
}
.playtime-box h3 {
    color: var(--accent2);
    margin-bottom: 19px;
    text-align: center;
    font-size: 1.13em;
    font-weight: bold;
    letter-spacing: .3px;
}
.playtime-list {
    margin: 0;
    padding: 0;
    list-style: none;
}
.playtime-list li {
    padding: 10px 0 7px 0;
    border-bottom: 1px solid #c0c0c033;
    display: flex;
    align-items: center;
    gap: 11px;
    font-size: 1.08em;
}
.playtime-list li:last-child { border-bottom: none;}
.playtime-list .pt-icon {
    font-size: 1.18em;
    color: var(--accent2);
    margin-left: 8px;
}
.pt-server { min-width: 90px; display: inline-block; font-weight: bold;}
.pt-time   { color: var(--accent2); font-weight: bold;}
@media (max-width: 900px) {
    .dashboard-container {flex-direction:column;}
    .sidebar {width:100%;min-width:0;flex-direction:row;justify-content:center;}
    .main-content {padding: 24px 8px;}
}
@media (max-width: 600px) {
    .main-content {padding: 9px 2vw;}
    .welcome-card {flex-direction:column;gap:15px;}
    .sidebar {padding:14px 0;}
    .sidebar .avatar {width:50px;height:50px;}
    .sidebar .username {font-size:1.01rem;}
    .sidebar-menu a {font-size:.93rem;padding:8px 15px;}
    .playtime-box {max-width:97vw;padding:10px 4vw;}
}
    </style>
</head>
<body>
<div class="dashboard-container">
    <!-- Sidebar -->
    <div class="sidebar">
        <img class="avatar" src="<?=htmlspecialchars($avatar)?>" alt="avatar">
        <div class="username"><?=htmlspecialchars($user['username'])?></div>
        <div class="user-rank"><?=minecraft_colored_rank($my_ranksystem_rank_name)?></div>
        <?php if($registered_email): ?>
            <div class="sidebar-contact"><i class="bx bxs-envelope"></i><?=htmlspecialchars($registered_email)?></div>
        <?php endif; ?>
        <?php if($registered_phone): ?>
            <div class="sidebar-contact"><i class="bx bxs-phone"></i><?=htmlspecialchars($registered_phone)?></div>
        <?php endif; ?>
        <nav class="sidebar-menu">
            <ul>
                <li><a class="active" href="#"><i class="bx bxs-dashboard"></i><span>داشبورد</span></a></li>
                <li>
                    <a href="tickets.php">
                        <i class="bx bxs-message-dots"></i>تیکت پشتیبانی
                        <?php if($new_messages): ?><span class="badge"><?=$new_messages?></span><?php endif; ?>
                    </a>
                </li>
                <li><a href="shop.php"><i class="bx bxs-store"></i>فروشگاه</a></li>
                <li>
                    <a href="chat.php">
                        <i class="bx bxs-chat"></i>چت آنلاین
                    </a>
                </li>
                <li><a href="#"><i class="bx bxs-bar-chart-alt-2"></i>وضعیت</a></li>
                <?php if (in_array($user_role, $allowed_roles)): ?>
                    <li>
                        <a href="open_tickets.php"><i class="bx bx-support"></i>
                            تیکت‌های باز
                            <?php if($open_tickets_count): ?>
                                <span class="badge"><?=$open_tickets_count?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li>
                        <a href="open_chats.php"><i class="bx bx-message-dots"></i>
                            چت‌های باز
                            <?php if($open_chats_count): ?>
                                <span class="badge"><?=$open_chats_count?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
        <form method="post" action="player_logout.php" style="width:100%">
            <button type="submit" class="logout-btn"><i class="bx bx-log-out" style="vertical-align:middle;margin-left:7px;"></i>خروج</button>
        </form>
        <div class="sidebar-footer">
            <a href="#">قوانین سایت</a>
        </div>
    </div>
    <!-- Main Content -->
    <div class="main-content">
        <?php if ($new_support_msg): ?>
            <div style="background:#ffc107;color:#222;padding:11px 22px;border-radius:8px;margin-bottom:20px;box-shadow:0 2px 18px #23243a33;">
                <b>پیام جدید از تیم پشتیبانی:</b>
                <span><?= htmlspecialchars($support_msg_text) ?></span>
                <a href="chat_online.php" style="margin-right:22px;color:#007bff;text-decoration:underline;">رفتن به چت آنلاین</a>
            </div>
        <?php endif; ?>
        <div class="welcome-card">
            <div class="welcome-text">
                <h2><?=htmlspecialchars($user['username'])?></h2>
                <h3>خوش آمدید به پنل پیشرفته پلیر! اینجا می‌توانید وضعیت، پیشرفت و امکانات حساب خود را مدیریت کنید.</h3>
            </div>
            <img class="welcome-img" src="logo.png" alt="">
        </div>
        <div class="profile-card">
            <div class="profile-info">
                <div class="profile-info-row"><strong>نام کاربری:</strong> <?=htmlspecialchars($user['username'])?></div>
                <div class="profile-info-row"><strong>آخرین ورود:</strong> <?=$last_login?></div>
                <div class="profile-info-row"><strong>تاریخ ساخت اکانت:</strong> <?=$created_at?></div>
                <div class="profile-info-row"><strong>رنک:</strong> <span><?=minecraft_colored_rank($my_ranksystem_rank_name)?></span></div>
                <div class="profile-info-row">
                    <strong>دسترسی‌ها:</strong>
                    <span style="color:var(--primary);"><?=htmlspecialchars($my_ranksystem_perms)?></span>
                </div>
            </div>
        </div>
        <div class="dashboard-row">
            <div class="dashboard-box">
                <div class="title">NovaCoin</div>
                <div class="dashboard-stat">
                    <div class="label">&nbsp;</div>
                    <div class="value novacoin"><?=format_fa_num($novacoin)?> <i class="bx bx-diamond"></i></div>
                </div>
            </div>
            <div class="dashboard-box">
                <div class="title">مقدار پول</div>
                <div class="dashboard-stat">
                    <div class="label">&nbsp;</div>
                    <div class="value money"><?=format_fa_num($money)?> <i class="bx bxs-wallet"></i></div>
                </div>
            </div>
            <div class="dashboard-box">
                <div class="title">اطلاعات بن اکانت</div>
                <div class="dashboard-stat">
                    <div class="label">&nbsp;</div>
                    <div class="value <?= $ban_account ? 'danger' : 'success' ?>">
                        <?=$ban_account ? 'بن شده' : 'شما بن اکانت نیستید.'?>
                    </div>
                </div>
            </div>
            <div class="dashboard-box">
                <div class="title">تایم پلی کل</div>
                <div class="dashboard-stat">
                    <div class="label">&nbsp;</div>
                    <div class="value blue"><?=$play_time?> <i class="bx bx-time"></i></div>
                </div>
            </div>
            <!-- باکس رنک خوشگل -->
            <div class="dashboard-box rank-box">
                <div class="title">رنک</div>
                <div class="dashboard-stat">
                    <div class="label">&nbsp;</div>
                    <div class="pretty-rank-wrapper">
                        <span class="pretty-rank"><?=minecraft_colored_rank($my_ranksystem_rank_name)?></span>
                        <i class="bx bxs-crown"></i>
                    </div>
                </div>
            </div>
        </div>
        <!-- باکس تایم پلی -->
        <div class="playtime-box">
            <h3><i class="bx bx-time" style="color:var(--accent2);vertical-align:middle;margin-left:7px;"></i>تایم پلی در سرورها</h3>
            <ul class="playtime-list">
                <?php foreach($play_times as $server => $t): ?>
                <li>
                    <i class="bx bx-server pt-icon"></i>
                    <span class="pt-server"><?=htmlspecialchars($server)?></span>
                    <span class="pt-time"><?=format_fa_num($t['minutes'])?> دقیقه</span>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</div>
</body>
</html>