<?php
session_start();
require_once "db.php";
$error = "";

// تولید کد کپچا و ذخیره در سشن
function generate_captcha() {
    $pool = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz';
    $code = '';
    for ($i = 0; $i < 5; $i++)
        $code .= $pool[random_int(0, strlen($pool)-1)];
    $_SESSION['captcha_code'] = $code;
    return $code;
}

// اگر کپچا جدید خواست
if (isset($_GET['refresh_captcha'])) {
    echo generate_captcha();
    exit;
}

// اگر فرم ارسال شده
if (isset($_POST['username'], $_POST['password'], $_POST['captcha'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $user_captcha = trim($_POST['captcha']);

    // کپچا چک
    if (!isset($_SESSION['captcha_code']) || strtolower($user_captcha) !== strtolower($_SESSION['captcha_code'])) {
        $error = "کد امنیتی درست وارد نشده است!";
        generate_captcha(); // کپچای جدید بساز
    } else {
        $stmt = $conn->prepare("SELECT * FROM users WHERE username=? AND password=?");
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user) {
            $_SESSION['player_logged_in'] = true;
            $_SESSION['player_username'] = $user['username'];
            header("Location: Dashboard.php");
            exit();
        } else {
            $error = "نام کاربری یا رمز اشتباه است!";
            generate_captcha();
        }
    }
} else {
    // اولین بار یا اگر پر نشده بود کپچا تولید کن
    if (!isset($_SESSION['captcha_code'])) generate_captcha();
}
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>ورود بازیکن</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- فونت دلخواه (مثلاً Vazirmatn) -->
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700&display=swap" rel="stylesheet">
    <style>
    :root {
        --primary: #c0c0c0;
        --secondary: #a0a0a0;
        --dark: #202020;
        --light: #f4f4f4;
        --silver: #c0c0c0;
        --silver-dark: #a0a0a0;
        --glass: rgba(255, 255, 255, 0.1);
        --glass-border: rgba(255, 255, 255, 0.2);
        --accent: #c0c0c0;
        --accent-light: #e8e8e8;
    }
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Vazirmatn', sans-serif;
    }
    body {
        background: linear-gradient(135deg, var(--dark), #34343e);
        color: white;
        min-height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        overflow: hidden;
    }
    .floating-buttons {
        position: absolute;
        top: 0; left: 0;
        width: 100%; height: 100%;
        pointer-events: none;
        z-index: 0;
    }
    .floating-btn {
        position: absolute;
        background: rgba(192, 192, 192, 0.12);
        border-radius: 50%;
        backdrop-filter: blur(5px);
        animation: float 15s infinite linear;
        pointer-events: none;
        border: 1px solid rgba(192, 192, 192, 0.2);
    }
    @keyframes float {
        0% { transform: translateY(0) rotate(0deg);}
        100% {transform: translateY(-100vh) rotate(360deg);}
    }
    .login-container {
        position: relative;
        z-index: 10;
        width: 100%;
        max-width: 400px;
        padding: 40px;
        background: rgba(32, 32, 32, 0.8);
        backdrop-filter: blur(16px);
        border-radius: 24px;
        border: 1px solid var(--glass-border);
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.36), inset 0 4px 8px rgba(255,255,255,0.05);
        transform: scale(0.95);
        opacity: 0;
        animation: fadeInUp 0.8s 0.3s forwards;
        margin: 0 auto;
    }
    @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(20px) scale(0.95);}
        to {opacity: 1; transform: translateY(0) scale(1);}
    }
    .login-header {
        text-align: center;
        margin-bottom: 30px;
    }
    .login-logo {
        width: 80px;
        height: 80px;
        margin: 0 auto 15px auto;
        display: flex;
        justify-content: center;
        align-items: center;
        filter: drop-shadow(0 0 10px rgba(192,192,192,0.3));
        animation: pulse 2s infinite alternate;
    }
    .login-logo img {
        width: 80px;
        height: 80px;
        object-fit: contain;
        border-radius: 16px;
        display: block;
        margin: 0 auto;
    }
    @keyframes pulse {
        from { filter: drop-shadow(0 0 10px rgba(192,192,192,0.4)); }
        to { filter: drop-shadow(0 0 22px rgba(160,160,160,0.6)); }
    }
    .login-title {
        font-size: 1.8rem;
        font-weight: 700;
        background: linear-gradient(to right, var(--primary), var(--accent-light));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 10px;
        text-shadow: 0 2px 4px rgba(0,0,0,0.3);
    }
    .login-subtitle {
        color: var(--silver-dark);
        font-size: 0.9rem;
    }
    .login-form .form-group {
        margin-bottom: 20px;
    }
    .login-form label {
        display: block;
        margin-bottom: 8px;
        color: var(--silver);
        font-size: 0.9rem;
    }
    .login-form input {
        width: 100%;
        padding: 12px 16px;
        background: rgba(255,255,255,0.08);
        border: 1px solid var(--glass-border);
        border-radius: 12px;
        color: white;
        transition: all 0.3s;
    }
    .login-form input:focus {
        outline: none;
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(192,192,192,0.22);
    }
    .captcha-row {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 10px;
    }
    .captcha-img {
        font-family: monospace;
        font-size: 1.29rem;
        letter-spacing: 6px;
        color: #23242a;
        background: linear-gradient(120deg,#fff,#c0c0c0 80%);
        border-radius: 9px;
        padding: 8px 16px 5px 16px;
        font-weight: 800;
        box-shadow: 0 1px 10px #fff3;
        user-select: none;
        border: 1px solid #c0c0c088;
        position: relative;
        text-shadow: 0 1px 1px #fff, 0 2px 2px #c0c0c033;
        direction: ltr;
    }
    .captcha-refresh {
        cursor: pointer;
        background: transparent;
        border: none;
        color: #a0a0a0;
        font-size: 1.25em;
        margin-right: 5px;
        transition: color .2s, transform .2s;
        padding: 0 5px;
    }
    .captcha-refresh:hover {
        color: #fff;
        transform: rotate(-30deg) scale(1.18);
    }
    .login-btn {
        width: 100%;
        padding: 14px;
        background: linear-gradient(135deg, rgba(192,192,192,0.23), rgba(160,160,160,0.18));
        border: none;
        border-radius: 12px;
        color: white;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.3s;
        position: relative;
        overflow: hidden;
        margin-top: 20px;
        border: 1px solid rgba(192,192,192,0.36);
    }
    .login-btn::before {
        content: '';
        position: absolute;
        top: 0; left: -100%;
        width: 100%; height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.17), transparent);
        transition: 0.5s;
    }
    .login-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(192,192,192, 0.17);
    }
    .login-btn:hover::before {
        left: 100%;
    }
    .error-message {
        color: #ff6b6b;
        text-align: center;
        margin-top: 15px;
        font-size: 0.9rem;
        height: 20px;
    }
    .error-message.active {
        animation: shake 0.5s;
    }
    @keyframes shake {
        0%, 100% { transform: translateX(0);}
        20%, 60% {transform: translateX(-5px);}
        40%, 80% {transform: translateX(5px);}
    }
    .light-effect {
        position: absolute;
        width: 300px;
        height: 300px;
        border-radius: 50%;
        background: radial-gradient(circle, rgba(192,192,192,0.10), transparent 70%);
        z-index: -1;
    }
    .light-effect:nth-child(1) {
        top: -100px;
        right: -100px;
        animation: moveLight1 15s infinite alternate;
    }
    .light-effect:nth-child(2) {
        bottom: -150px;
        left: -100px;
        animation: moveLight2 20s infinite alternate;
    }
    @keyframes moveLight1 {
        0% { transform: translate(0,0);}
        100% {transform: translate(50px, 60px);}
    }
    @keyframes moveLight2 {
        0% { transform: translate(0,0);}
        100% {transform: translate(-50px, -40px);}
    }
    @media (max-width: 576px) {
        .login-container {
            padding: 30px 10px;
            margin: 0 5px;
        }
        .login-title { font-size: 1.4rem;}
    }
    </style>
</head>
<body>
    <div class="floating-buttons">
        <div class="floating-btn" style="width:100px; height:100px; top:20%; left:10%; animation-duration: 13s;"></div>
        <div class="floating-btn" style="width:60px; height:60px; top:70%; left:80%; animation-duration: 19s;"></div>
        <div class="floating-btn" style="width:40px; height:40px; top:60%; left:20%; animation-duration: 9s;"></div>
        <div class="floating-btn" style="width:80px; height:80px; top:10%; left:60%; animation-duration: 16s;"></div>
    </div>
    <div class="login-container">
        <div class="login-header">
            <div class="login-logo">
                <!-- لوگوی اختصاصی سایتت را اینجا جایگزین کن -->
                <img src="logo.png" alt="Player Panel Logo">
            </div>
            <div class="login-title">ورود به پنل پلیر</div>
            <div class="login-subtitle">نام کاربری و رمز عبور خود را وارد کنید</div>
        </div>
        <form class="login-form" method="post" autocomplete="off">
            <div class="form-group">
                <label for="username">نام کاربری</label>
                <input type="text" id="username" name="username" placeholder="نام کاربری" required>
            </div>
            <div class="form-group">
                <label for="password">رمز عبور</label>
                <input type="password" id="password" name="password" placeholder="رمز عبور" required>
            </div>
            <div class="form-group">
                <label for="captcha">کد امنیتی</label>
                <div class="captcha-row">
                    <span class="captcha-img" id="captcharender"><?= htmlspecialchars($_SESSION['captcha_code']??'') ?></span>
                    <button type="button" class="captcha-refresh" title="کپچا جدید" onclick="refreshCaptcha(this)">
                        &#x21bb;
                    </button>
                </div>
                <input type="text" id="captcha" name="captcha" placeholder="کد داخل تصویر" required autocomplete="off" maxlength="7">
            </div>
            <button class="login-btn" type="submit">ورود</button>
            <div class="error-message<?= $error ? ' active' : '' ?>">
                <?= htmlspecialchars($error) ?>
            </div>
        </form>
    </div>
    <div class="light-effect"></div>
    <div class="light-effect"></div>
    <script>
    function refreshCaptcha(btn) {
        btn.disabled = true;
        fetch('?refresh_captcha=1')
            .then(res => res.text())
            .then(code => {
                document.getElementById('captcharender').textContent = code;
                btn.disabled = false;
            });
    }
    </script>
</body>
</html>