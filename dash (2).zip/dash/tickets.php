<?php
session_start();
$host = 'localhost';
$user = 'nC';
$pass = '15';
$dbname = 'nC';
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) { die("DB Error."); }
if (!isset($_SESSION['player_logged_in']) || !$_SESSION['player_logged_in']) {
    $_SESSION['player_logged_in'] = true;
    $_SESSION['player_username'] = "Mahdi";
}
$username = $_SESSION['player_username'];
header('Content-Type: text/html; charset=utf-8');

if (isset($_GET['api'])) {
    if ($_GET['api']==='tickets') {
        $arr=[];
        // اگر جدولت description نداره خط زیر رو به: SELECT id, title, status, DATE_FORMAT...
        $stmt=$conn->prepare("SELECT id, title, status, DATE_FORMAT(created_at,'%Y/%m/%d') as date FROM tickets WHERE user=? ORDER BY id DESC");
        $stmt->bind_param("s",$username); $stmt->execute(); $res=$stmt->get_result();
        while($row=$res->fetch_assoc())$arr[]=$row;$stmt->close();
        echo json_encode($arr,JSON_UNESCAPED_UNICODE);exit;
    }
    if ($_GET['api']==='messages' && isset($_GET['ticket_id'])) {
        $ticket_id=intval($_GET['ticket_id']);$arr=[];
        $stmt=$conn->prepare("SELECT sender,sender_type,message,DATE_FORMAT(sent_at,'%H:%i') as time FROM ticket_messages WHERE ticket_id=? ORDER BY id ASC");
        $stmt->bind_param("i",$ticket_id);$stmt->execute();
        $res=$stmt->get_result();
        while($row=$res->fetch_assoc())$arr[]=$row;$stmt->close();
        echo json_encode($arr,JSON_UNESCAPED_UNICODE);exit;
    }
    if ($_GET['api'] === 'ticket_details' && isset($_GET['ticket_id'])) {
        $ticket_id = intval($_GET['ticket_id']);
        // اگر جدولت description نداره، description رو حذف کن
        $stmt = $conn->prepare("SELECT *, (SELECT COUNT(*) FROM ticket_messages WHERE ticket_id=tickets.id) as msg_count FROM tickets WHERE id=?");
        $stmt->bind_param("i", $ticket_id);
        $stmt->execute();
        $t = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($t) {
            echo json_encode([
                'title' => $t['title'],
                'status' => $t['status'],
                'created_at' => $t['created_at'],
                'id' => $t['id'],
                'user' => $t['user'],
                'msg_count' => $t['msg_count']
            ], JSON_UNESCAPED_UNICODE); exit;
        }
        echo json_encode(['err'=>'not found']); exit;
    }
    if ($_GET['api']=='new_ticket' && $_SERVER['REQUEST_METHOD']==='POST') {
        $title=trim($_POST['title']??'');
        $desc=trim($_POST['description']??'');
        if(!$title||!$desc){http_response_code(422);exit("اطلاعات ناقص.");}
        // اگر جدولت description نداره خط پایین رو این بذار:
        $stmt=$conn->prepare("INSERT INTO tickets (user,title,status) VALUES (?,?,'open')");
        $stmt->bind_param("ss",$username,$title);
        $stmt->execute();
        $ticket_id=$conn->insert_id;
        $stmt->close();
        $stmt2=$conn->prepare("INSERT INTO ticket_messages (ticket_id,sender,sender_type,message) VALUES (?,?, 'user', ?)");
        $stmt2->bind_param("iss",$ticket_id,$username,$desc);
        $stmt2->execute();$stmt2->close();
        echo json_encode(['ok'=>1,'id'=>$ticket_id]);exit;
    }
    if ($_GET['api']=='send_message' && $_SERVER['REQUEST_METHOD']==='POST') {
        $ticket_id=intval($_POST['ticket_id']??0);$msg=trim($_POST['message']??'');
        if(!$ticket_id||!$msg){http_response_code(422);exit("اطلاعات ناقص.");}
        $stmt=$conn->prepare("SELECT id,status FROM tickets WHERE id=? AND user=?");
        $stmt->bind_param("is",$ticket_id,$username);$stmt->execute();
        $ok=$stmt->get_result()->fetch_assoc();$stmt->close();
        if(!$ok||$ok['status']!=='open'){http_response_code(403);exit("تیکت بسته است یا دسترسی غیرمجاز.");}
        $stmt2=$conn->prepare("INSERT INTO ticket_messages (ticket_id,sender,sender_type,message) VALUES (?,?, 'user', ?)");
        $stmt2->bind_param("iss",$ticket_id,$username,$msg);$stmt2->execute();$stmt2->close();
        echo json_encode(['ok'=>1]);exit;
    }
    if ($_GET['api']=='close_ticket' && isset($_POST['ticket_id'])) {
        $ticket_id=intval($_POST['ticket_id']);
        $stmt=$conn->prepare("UPDATE tickets SET status='closed' WHERE id=? AND user=?");
        $stmt->bind_param("is",$ticket_id,$username);$stmt->execute();$stmt->close();
        echo json_encode(['ok'=>1]);exit;
    }
    if ($_GET['api']=='clear_tickets') {
        $stmt = $conn->prepare("SELECT id FROM tickets WHERE user=?");
        $stmt->bind_param("s", $username); $stmt->execute();
        $res = $stmt->get_result();
        while($row = $res->fetch_assoc()) {
            $tid = $row['id'];
            $conn->query("DELETE FROM ticket_messages WHERE ticket_id=$tid");
        }
        $stmt = $conn->prepare("DELETE FROM tickets WHERE user=?");
        $stmt->bind_param("s",$username);$stmt->execute();$stmt->close();
        echo json_encode(['ok'=>1]); exit;
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>تیکت پلیر | شیشه‌ای</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700&display=swap">
<style>
body {
  font-family: 'Vazirmatn', 'IRANSans', Tahoma, sans-serif;
  background: radial-gradient(ellipse at 50% 30%, #181f26 60%, #12171e 100%);
  margin: 0;
  min-height: 100vh;
  color: #fff;
  transition: background 0.35s, color 0.35s;
}
[data-theme="light"] body {
  background: radial-gradient(ellipse at 50% 30%, #e8f3ff 60%, #c8e0ff 100%);
  color: #23242a;
}
.ticket-app-frame {
  max-width: 1500px;
  margin: 0 auto;
  padding: 40px 0;
  border-radius: 32px;
  border: 2px solid #23282f;
  background: rgba(24, 28, 33, 0.1);
  box-shadow: 0 0 0 2px rgba(30,40,60,0.2), 0 32px 64px 0 #0a101a99;
  position: relative;
  transition: background 0.4s;
}
[data-theme="light"] .ticket-app-frame {
  background: rgba(255,255,255,0.87);
  border: 2px solid #b8cbe5;
  box-shadow: 0 0 0 2px #b8cbe5, 0 32px 64px 0 #b7d8f4a0;
}
.ticket-app-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
  padding: 0 28px;
}
.ticket-app-title {
  font-size: 2rem;
  font-weight: 700;
  color: #fff;
  margin: 0;
}
[data-theme="light"] .ticket-app-title { color: #23242a; }
.theme-toggle-btn {
  background: #23282f;
  border-radius: 12px;
  color: #fff;
  border: 1.2px solid #23282f;
  font-size: 1.15rem;
  font-weight: 600;
  padding: 9px 28px 7px 28px;
  cursor: pointer;
  outline: none;
  transition: background .17s, color .17s, border .15s;
  margin-right: 0;
  margin-left: 8px;
}
.theme-toggle-btn:hover {
  background: #1ce2eb;
  color: #23282f;
  border-color: #1ce2eb;
}
.ticket-back-btn {
  background: #23282f;
  color: #fff;
  border-radius: 13px;
  font-size: 1.08rem;
  border: 1.2px solid #23282f;
  font-weight: 600;
  padding: 10px 22px 8px 22px;
  cursor: pointer;
  transition: filter .13s, background .16s;
  margin-left: 0;
  margin-right: 8px;
}
.ticket-back-btn:hover {
  filter: brightness(1.10);
  background: #1ce2eb;
  color: #23282f;
  border-color: #1ce2eb;
}
.ticket-app-container {
  display: flex;
  gap: 20px;
  justify-content: center;
}
.ticket-sidebar,
.ticket-details,
.ticket-chat {
  background: rgba(37, 40, 46, 0.92);
  border-radius: 24px;
  border: 2px solid #23282f;
  min-width: 350px;
  min-height: 700px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: stretch;
  transition: background 0.35s;
}
[data-theme="light"] .ticket-sidebar,
[data-theme="light"] .ticket-details,
[data-theme="light"] .ticket-chat {
  background: #f7fbff;
  border: 2px solid #b8cbe5;
}
.ticket-sidebar {
  max-width: 350px;
  width: 350px;
  padding: 0 0 18px 0;
  position: relative;
}
.ticket-sidebar-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 28px 30px 16px 30px;
}
.ticket-sidebar-header h2 {
  font-size: 2rem;
  font-weight: 700;
  margin: 0;
  letter-spacing: -1px;
}
.ticket-list {
  margin: 0;
  padding: 0 30px;
  flex: 1;
  overflow-y: auto;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.ticket-item {
  background: transparent;
  border-radius: 18px;
  border: 1.7px solid #23282f;
  padding: 20px 22px 16px 22px;
  cursor: pointer;
  transition: background .22s, box-shadow .19s;
  margin-bottom: 2px;
  display: flex;
  flex-direction: column;
  gap: 5px;
  position: relative;
}
.ticket-item.selected {
  background: linear-gradient(90deg, #1ce2eb 0%, #15b7c8 100%);
  box-shadow: 0 6px 24px 0 #00fbe380;
  color: #fff;
  border-color: #1ce2eb;
}
.ticket-item.selected .ticket-title,
.ticket-item.selected .ticket-desc,
.ticket-item.selected .ticket-meta,
.ticket-item.selected .ticket-status {
  color: #fff !important;
}
.ticket-title {
  font-weight: 700;
  font-size: 1.1rem;
  margin-bottom: 3px;
  color: #fff;
}
[data-theme="light"] .ticket-title { color: #23242a; }
.ticket-desc {
  font-size: 1rem;
  color: #a5a8b4;
  margin-bottom: 1px;
}
[data-theme="light"] .ticket-desc { color: #5480a7; }
.ticket-meta {
  display: flex;
  justify-content: space-between;
  font-size: 0.97rem;
  color: #b8beca;
}
[data-theme="light"] .ticket-meta { color: #5480a7; }
.ticket-status {
  font-size: 1rem;
  border-radius: 8px;
  padding: 0 7px;
  font-weight: 700;
  letter-spacing: -.5px;
}
.ticket-status.open { color: #00e889; }
.ticket-status.closed { color: #ff7171; }
[data-theme="light"] .ticket-status.open { color: #1b8d71; }
[data-theme="light"] .ticket-status.closed { color: #e84e4e; }
.ticket-sidebar-footer {
  margin-top: 16px;
  padding: 0 30px 10px 30px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.ticket-sidebar-footer {
  margin-bottom: 10px;
}
.btn-main,
.ticket-sidebar-footer button {
  width: 100%;
  padding: 13px 0 11px 0;
  background: linear-gradient(90deg,#25e0e8 0%,#11b9cf 100%);
  color: #fff;
  font-weight: 700;
  font-size: 1.1rem;
  border-radius: 16px;
  border: none;
  margin-top: 6px;
  letter-spacing: -.5px;
  cursor: pointer;
  transition: filter .14s, box-shadow .21s, background .23s;
  box-shadow: 0 1px 10px 0 #11b9cf21;
}
.btn-main:hover,
.ticket-sidebar-footer button:hover {
  filter: brightness(1.10);
  box-shadow: 0 6px 30px 0 #1ce2eb3a;
  background: linear-gradient(90deg, #11b9cf 0%, #25e0e8 100%);
}
.ticket-details {
  max-width: 380px;
  width: 380px;
  align-items: center;
  padding: 0 0 18px 0;
}
.ticket-details-header {
  text-align: center;
  padding: 28px 0 16px 0;
  font-size: 1.4rem;
  font-weight: 700;
  color: #fff;
}
[data-theme="light"] .ticket-details-header { color: #23242a; }
.ticket-details-block {
  margin: 0 24px;
  background: rgba(20,22,26,0.85);
  border-radius: 18px;
  border: 1.5px solid #23282f;
  padding: 32px 24px 32px 24px;
  color: #d2d2dd;
  font-size: 1.12rem;
  min-height: 420px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}
[data-theme="light"] .ticket-details-block {
  background: #f2f8fe;
  color: #23242a;
  border: 1.5px solid #b8cbe5;
}
.ticket-details-block b {
  color: #fff;
}
[data-theme="light"] .ticket-details-block b { color: #23242a; }
.ticket-chat {
  flex: 1 1 auto;
  min-width: 420px;
  max-width: 600px;
  align-items: stretch;
  padding: 0 0 18px 0;
}
.ticket-chat-header {
  text-align: center;
  padding: 28px 0 12px 0;
  font-size: 1.4rem;
  font-weight: 700;
  color: #fff;
}
[data-theme="light"] .ticket-chat-header { color: #23242a; }
.ticket-msg-list {
  flex: 1 1 auto;
  padding: 28px 36px 20px 36px;
  min-height: 330px;
  max-height: 420px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 20px;
}
.ticket-msg {
  max-width: 82%;
  min-width: 80px;
  padding: 16px 18px;
  border-radius: 14px;
  font-size: 1.14rem;
  word-break: break-word;
  background: #1ce2eb;
  color: #222;
  align-self: flex-start;
  position: relative;
  box-shadow: 0 1px 18px 0 #1ce2eb30;
}
.ticket-msg.staff {
  background: #23282f;
  color: #fff;
  align-self: flex-end;
  box-shadow: 0 1px 8px 0 #1ce2eb08;
}
[data-theme="light"] .ticket-msg {
  background: #e1fbff;
  color: #23242a;
}
[data-theme="light"] .ticket-msg.staff {
  background: #c4e4fa;
  color: #23242a;
}
.ticket-msg-time {
  font-size: 0.98rem;
  color: #a1e4f5;
  margin-top: 7px;
  opacity: .7;
  text-align: left;
}
.ticket-chat-form-row {
  display: flex;
  align-items: center;
  border-top: 1.5px solid #23282f;
  padding: 18px 36px 0 36px;
  margin-top: auto;
  gap: 9px;
}
[data-theme="light"] .ticket-chat-form-row {
  border-top: 1.5px solid #b8cbe5;
}
.ticket-chat-form-row input[type="text"] {
  background: #23282f;
  border: none;
  border-radius: 16px;
  font-size: 1.1rem;
  color: #fff;
  padding: 13px 18px;
  flex: 1;
  margin-left: 9px;
  outline: none;
  transition: background .14s;
}
[data-theme="light"] .ticket-chat-form-row input[type="text"] {
  background: #f7fbff;
  color: #23242a;
}
.ticket-chat-form-row input[type="text"]:focus {
  background: #29333d;
}
[data-theme="light"] .ticket-chat-form-row input[type="text"]:focus {
  background: #fff;
}
.ticket-chat-form-row button {
  background: #d2d2dd;
  color: #23282f;
  border: none;
  border-radius: 13px;
  font-weight: 700;
  font-size: 1.1rem;
  padding: 12px 34px 10px 34px;
  cursor: pointer;
  transition: filter .15s, background .17s;
}
.ticket-chat-form-row button:hover {
  filter: brightness(1.04);
  background: #fff;
}
::-webkit-scrollbar {width:8px;background:rgba(255,255,255,0.09);border-radius:10px;}
::-webkit-scrollbar-thumb {background: #23282f; border-radius: 10px;}
</style>
</head>
<body>
<div class="ticket-app-frame">
  <div class="ticket-app-header">
    <button class="ticket-back-btn" onclick="window.location='dashboard.php'">⟵ بازگشت به داشبورد</button>
    <span class="ticket-app-title">Nova Collective Tickets</span>
    <button class="theme-toggle-btn" id="theme-toggle-btn" title="تغییر حالت روز/شب">🌙</button>
  </div>
  <div class="ticket-app-container">
    <!-- Sidebar -->
    <aside class="ticket-sidebar">
      <div class="ticket-sidebar-header">
        <h2>تیکت‌ها</h2>
      </div>
      <ul class="ticket-list" id="ticket-list"></ul>
      <div class="ticket-sidebar-footer">
        <button id="create-ticket-btn" class="btn-main">تیکت جدید +</button>
        <button id="clear-btn" class="btn-main" style="background:linear-gradient(90deg,#23282f 0%,#2e3c47 100%);color:#fff;">پاک‌سازی لیست</button>
      </div>
    </aside>
    <!-- Main Chat -->
    <main class="ticket-chat">
      <div class="ticket-chat-header" id="ticket-title">انتخاب تیکت...</div>
      <section class="ticket-msg-list" id="chat-messages"></section>
      <form class="ticket-chat-form-row" id="chat-form" style="display:none">
        <input type="text" id="chat-input" placeholder="پیام خود را بنویسید..." autocomplete="off">
        <button type="submit">ارسال</button>
      </form>
    </main>
    <!-- Details -->
    <aside class="ticket-details">
      <div class="ticket-details-header">جزئیات تیکت</div>
      <div class="ticket-details-block" id="details-content">
        <p>برای مشاهده جزئیات، یک تیکت را انتخاب کنید.</p>
      </div>
    </aside>
  </div>
</div>
<!-- Modal ثبت تیکت جدید -->
<div id="modal-overlay" style="display:none;position:fixed;inset:0;z-index:999;align-items:center;justify-content:center;background:rgba(0,0,0,0.53)">
  <div class="modal-box" style="background:#23282f;color:#fff;border-radius:18px;padding:2.2rem 2.5rem;min-width:340px;box-shadow:0 6px 44px #11b9cf30;display:flex;flex-direction:column;gap:1.1rem;border:1.2px solid #23282f;">
    <h2>ثبت تیکت جدید</h2>
    <form id="new-ticket-form">
      <label>عنوان تیکت:</label>
      <input type="text" name="title" required maxlength="64" style="width:100%;border-radius:9px;border:1.1px solid #23282f;background:#23282f;color:#fff;padding:9px 13px;margin-bottom:7px;font-size:1em;font-family:inherit;">
      <label>توضیحات:</label>
      <textarea name="description" rows="3" required maxlength="1000" style="width:100%;border-radius:9px;border:1.1px solid #23282f;background:#23282f;color:#fff;padding:9px 13px;margin-bottom:7px;font-size:1em;font-family:inherit;"></textarea>
      <button type="submit" style="background:#1ce2eb;color:#222;border-radius:10px;border:none;font-weight:bold;font-size:1.05em;padding:8px 28px;margin:4px 3px;cursor:pointer;">ارسال</button>
      <button type="button" id="close-modal" style="background:#1a2026;color:#fff;border-radius:10px;padding:8px 28px;margin:4px 3px;cursor:pointer;">انصراف</button>
    </form>
  </div>
</div>
<script>
let currentTicketId = null, lastUser = null, typingTimeout = null, ticketStatus = 'open';
const ticketList = document.getElementById('ticket-list');
const chatMessages = document.getElementById('chat-messages');
const chatForm = document.getElementById('chat-form');
const chatInput = document.getElementById('chat-input');
const ticketTitle = document.getElementById('ticket-title');
const detailsContent = document.getElementById('details-content');
const modal = document.getElementById('modal-overlay');
// Theme toggle logic
const themeToggleBtn = document.getElementById('theme-toggle-btn');
const htmlEl = document.documentElement;
function setTheme(mode) {
  if(mode==='light') {
    htmlEl.setAttribute('data-theme','light');
    themeToggleBtn.innerHTML = "🌞";
  } else {
    htmlEl.setAttribute('data-theme','dark');
    themeToggleBtn.innerHTML = "🌙";
  }
  localStorage.setItem('ticket_theme',mode);
}
themeToggleBtn.onclick = function() {
  let mode = htmlEl.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
  setTheme(mode);
};
(function() {
  let mode = localStorage.getItem('ticket_theme');
  if (mode && mode!=='dark') setTheme(mode);
  else setTheme('dark');
})();
document.getElementById('create-ticket-btn').onclick = () => {
  modal.style.display = 'flex';
  document.querySelector('#modal-overlay input[name="title"]').focus();
};
document.getElementById('close-modal').onclick = () => {
  modal.style.display = 'none';
};
document.getElementById('new-ticket-form').onsubmit = async function(e) {
  e.preventDefault();
  const title = this.title.value.trim();
  const desc = this.description.value.trim();
  if(!title || !desc) return;
  const fd = new FormData(this);
  let res = await fetch('?api=new_ticket', { method: 'POST', body: fd });
  if(res.ok) {
    modal.style.display = 'none';
    this.reset();
    await loadTickets();
  }
};
document.getElementById('clear-btn').onclick = async function() {
  if(confirm('آیا مطمئن هستید که می‌خواهید تمام تیکت‌های خود را پاک کنید؟')) {
    await fetch('?api=clear_tickets');
    loadTickets();
    chatMessages.innerHTML = '';
    detailsContent.innerHTML = '<p>برای مشاهده جزئیات، یک تیکت را انتخاب کنید.</p>';
    ticketTitle.textContent = 'انتخاب تیکت...';
    chatForm.style.display = 'none';
  }
};
async function loadTickets(selectedTicket) {
  let res = await fetch('?api=tickets');
  let list = await res.json();
  ticketList.innerHTML = '';
  if(list.length===0) ticketList.innerHTML='<div style="color:#a5a8b4;text-align:center;padding:22px;">هیچ تیکتی ثبت نکرده‌اید.</div>';
  list.forEach(t=>{
    let li = document.createElement('li');
    li.className = 'ticket-item'+(t.id==selectedTicket?' selected':'');
    li.innerHTML = `<div class="ticket-title">${t.title}</div>
      <div class="ticket-meta"><span class="ticket-status ${t.status}">${t.status==='open'?'باز':'بسته'}</span><span>${t.date}</span></div>`;
    li.onclick = ()=>showTicket(t.id);
    ticketList.appendChild(li);
  });
  if(selectedTicket && list.some(t=>t.id==selectedTicket)) showTicket(selectedTicket);
}
async function showTicket(id) {
  currentTicketId = id;
  [...ticketList.children].forEach(li=>li.classList.remove('selected'));
  let li = [...ticketList.children].find(l=>l.textContent.includes(id));
  if(li) li.classList.add('selected');
  let tinfo = await fetch(`?api=ticket_details&ticket_id=${id}`).then(r=>r.json());
  ticketStatus = tinfo.status;
  ticketTitle.textContent = tinfo.title;
  detailsContent.innerHTML = `
    <b>عنوان:</b> ${tinfo.title}<br>
    <span><b>وضعیت:</b> ${tinfo.status==='open'?'باز':'بسته'}</span><br>
    <span><b>تاریخ ثبت:</b> ${tinfo.created_at}</span><br>
    <span><b>تعداد پیام‌ها:</b> ${tinfo.msg_count}</span>
  `;
  let res = await fetch(`?api=messages&ticket_id=${id}`);
  let msgs = await res.json();
  chatMessages.innerHTML = '';
  lastUser = tinfo.user;
  msgs.forEach((m,i)=>{
    let div = document.createElement('div');
    div.className = 'ticket-msg '+(m.sender_type==='user'?'':'staff');
    div.innerHTML = `<span>${m.message}</span>
      <div class="ticket-msg-time">${m.time}</div>`;
    chatMessages.appendChild(div);
  });
  chatMessages.scrollTop = chatMessages.scrollHeight;
  chatForm.style.display = (tinfo.status === 'open') ? '' : 'none';
}
chatForm.onsubmit = async function(e) {
  e.preventDefault();
  if(!currentTicketId) return;
  let txt = chatInput.value.trim();
  if(!txt || ticketStatus !== 'open') return;
  await fetch('?api=send_message', {
    method: 'POST',
    body: new URLSearchParams({ticket_id:currentTicketId, message:txt})
  });
  chatInput.value = '';
  showTicket(currentTicketId);
};
loadTickets();
</script>
</body>
</html>